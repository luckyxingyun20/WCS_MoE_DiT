#!/usr/bin/env python3
"""Small train/inference entry point for WCS-MoE-DiT on real ACDC images."""
import argparse
import copy
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from PIL import Image, ImageDraw
from torch.utils.data import DataLoader

from wcs_moe_dit.data import ACDCDataset, WEATHER_NAMES, colorize_mask
from wcs_moe_dit.diffusion import CosineDiffusion
from wcs_moe_dit.losses import clean_mask_target, compute_losses, utility_target
from wcs_moe_dit.model import WCSMoEDiT

PROJECT_ROOT = Path(__file__).resolve().parent


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(request):
    if request == 'auto':
        return torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    if request.startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA is unavailable in this process; use --device cpu.')
    return torch.device(request)


def load_config(args):
    with open(args.config, encoding='utf-8') as stream:
        cfg = yaml.safe_load(stream)
    if args.device:
        cfg['device'] = args.device
    if args.steps is not None:
        cfg['training']['steps'] = args.steps
    if args.output_dir:
        cfg['output_dir'] = args.output_dir
    if args.ablation:
        cfg['model']['enable_weather'] = args.ablation in ('weather', 'full')
        cfg['model']['enable_state'] = args.ablation in ('state', 'full')
    if cfg['training']['steps'] < 1:
        raise ValueError('training.steps must be positive')
    if cfg['training']['utility_every'] < 1:
        raise ValueError('utility_every must be positive')
    torch.set_num_threads(int(cfg.get('cpu_threads', 4)))
    return cfg


def output_path(cfg):
    path = Path(cfg['output_dir'])
    return path if path.is_absolute() else PROJECT_ROOT / path


def make_dataset(cfg, split):
    return ACDCDataset(
        root=cfg['data']['root'], split=split,
        image_size=cfg['data']['image_size'],
        limit_per_weather=cfg['data'][split + '_limit_per_weather'],
        augment=(split == 'train'))


def cycle_batches(loader):
    while True:
        for batch in loader:
            yield batch


def make_model(cfg, device, initialize_weather=False):
    model_cfg = copy.deepcopy(cfg['model'])
    embedding_file = cfg['weather'].get('embeddings_file')
    embeddings = None
    if embedding_file:
        embeddings = torch.load(embedding_file, map_location='cpu')
        if not torch.is_tensor(embeddings) or embeddings.ndim != 2 or embeddings.shape[0] != 4:
            raise ValueError('weather.embeddings_file must contain a [4,D] tensor')
        model_cfg['weather_embedding_dim'] = embeddings.shape[1]
        cfg['model']['weather_embedding_dim'] = embeddings.shape[1]
    model = WCSMoEDiT(**model_cfg)
    if embeddings is not None:
        model.set_weather_text_embeddings(embeddings.float(), is_pretrained_clip=True)
    if initialize_weather:
        local_weights = Path(cfg['weather'].get('imagenet_checkpoint') or '')
        if local_weights.is_file():
            state = torch.load(str(local_weights), map_location='cpu')
            state = {key: value for key, value in state.items() if not key.startswith('fc.')}
            missing, unexpected = model.weather_classifier.load_state_dict(state, strict=False)
            print('Weather classifier: local ImageNet ResNet-18 trunk loaded; four-class head is new.', flush=True)
            if set(missing) != {'fc.weight', 'fc.bias'} or unexpected:
                raise RuntimeError('Unexpected ResNet checkpoint mismatch: %s %s' % (missing, unexpected))
        else:
            print('Weather classifier: local weights missing, using random initialization.', flush=True)
    return model.to(device)


def train(cfg):
    seed_all(cfg['seed'])
    device = resolve_device(cfg['device'])
    out = output_path(cfg)
    out.mkdir(parents=True, exist_ok=True)
    dataset = make_dataset(cfg, 'train')
    if len(dataset) < 2:
        raise ValueError('Weather classifier training needs at least two samples')
    batch_size = min(int(cfg['training']['batch_size']), len(dataset))
    if batch_size < 2:
        raise ValueError('Use batch_size >= 2 for ResNet weather training')
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=True)
    batches = cycle_batches(loader)
    model = make_model(cfg, device, initialize_weather=True)
    diffusion = CosineDiffusion(**{key: value for key, value in cfg['diffusion'].items()
                                 if key != 'inference_steps'}).to(device)
    print('Environment: Python from openpcdet, torch=%s device=%s samples=%d' % (
        torch.__version__, device, len(dataset)), flush=True)
    if device.type == 'cuda':
        print('GPU: ' + torch.cuda.get_device_name(device), flush=True)
        torch.cuda.reset_peak_memory_stats(device)
    log_file = out / 'train_log.jsonl'
    started = time.time()
    log = []
    # The paper freezes an ACDC-trained classifier during segmentation.
    # This demo only exercises a few real weather-classification updates.
    for parameter in model.weather_classifier.parameters():
        parameter.requires_grad_(True)
    model.weather_classifier.train()
    weather_optimizer = torch.optim.AdamW(model.weather_classifier.parameters(),
                                         lr=cfg['weather']['learning_rate'])
    for step in range(int(cfg['weather']['pretrain_steps'])):
        batch = next(batches)
        image = batch['image'].to(device)
        weather = batch['weather'].to(device)
        image = (image - image.new_tensor([0.485, 0.456, 0.406])[None, :, None, None]) / image.new_tensor(
            [0.229, 0.224, 0.225])[None, :, None, None]
        logits = model.weather_classifier(image)
        loss = F.cross_entropy(logits, weather)
        weather_optimizer.zero_grad(set_to_none=True)
        loss.backward()
        weather_optimizer.step()
        record = {'phase': 'weather', 'step': step + 1, 'loss': float(loss.detach())}
        log.append(record)
        print('Weather %d/%d CE=%.4f' % (step + 1, cfg['weather']['pretrain_steps'], record['loss']), flush=True)
    for parameter in model.weather_classifier.parameters():
        parameter.requires_grad_(False)
    model.weather_classifier.eval()
    model.train()
    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),
                                  lr=cfg['training']['learning_rate'],
                                  weight_decay=cfg['training']['weight_decay'])
    utility_updates = 0
    mix = torch.tensor(cfg['training']['weather_probability_mix'], device=device, dtype=torch.float)
    if mix.shape != (3,) or (mix < 0).any() or not torch.isclose(mix.sum(), mix.new_tensor(1.0)):
        raise ValueError('weather_probability_mix must be three probabilities summing to one')
    for step in range(int(cfg['training']['steps'])):
        batch = next(batches)
        image, labels = batch['image'].to(device), batch['label'].to(device)
        target, valid_low = clean_mask_target(labels, cfg['model']['num_classes'])
        timestep = torch.randint(1, diffusion.training_steps + 1, (image.shape[0],), device=device)
        noisy = diffusion.q_sample(target, timestep)
        condition = model.encode_condition(image)
        probabilities = condition['weather_probs'].clone()
        # Rebuild weather representation through the public conditioning path,
        # so the learnable weather projection keeps its segmentation gradients.
        choices = torch.multinomial(mix, image.shape[0], replacement=True)
        incorrect = (batch['weather'].to(device) + torch.randint(1, 4, (image.shape[0],), device=device)) % 4
        probabilities = torch.where((choices == 1)[:, None], F.one_hot(incorrect, 4).float(), probabilities)
        probabilities = torch.where((choices == 2)[:, None], torch.full_like(probabilities, 0.25), probabilities)
        # Avoid encoding RGB twice: project the perturbed distribution into the cached condition.
        condition['weather_probs'] = probabilities
        condition['weather_vector'] = model.weather_projection(probabilities @ model.weather_embeddings)
        prefix = model.prepare_prefix(noisy, timestep, condition)
        utility = None
        scheduled = (cfg['model']['enable_weather'] and step >= cfg['training']['utility_start']
                     and (step - cfg['training']['utility_start']) % cfg['training']['utility_every'] == 0)
        if scheduled:
            with torch.no_grad():
                on = model.decode_suffix(prefix, weather_gate_override=1.0)
                off = model.decode_suffix(prefix, weather_gate_override=0.0)
                utility = utility_target(on['logits'], off['logits'], labels,
                                         prefix['grid_size'], cfg['training']['utility_temperature'])
            utility_updates += 1
        output = dict(prefix)
        output.update(model.decode_suffix(prefix))
        losses = compute_losses(output, labels, target, valid_low, diffusion.alpha_bar[timestep],
                                utility=utility, enable_weather=cfg['model']['enable_weather'],
                                enable_state=cfg['model']['enable_state'])
        if not all(torch.isfinite(value).all() for value in losses.values()):
            raise RuntimeError('Non-finite training loss')
        optimizer.zero_grad(set_to_none=True)
        losses['total'].backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), cfg['training']['grad_clip'])
        if not torch.isfinite(grad_norm):
            raise RuntimeError('Non-finite gradient')
        optimizer.step()
        record = {'phase': 'segmentation', 'step': step + 1,
                  **{name: float(value.detach()) for name, value in losses.items()},
                  'utility_scheduled': bool(scheduled), 'grad_norm': float(grad_norm),
                  'timestep': timestep.tolist()}
        log.append(record)
        print('Segmentation %d/%d total=%.4f seg=%.4f util=%.4f str=%.6f' % (
            step + 1, cfg['training']['steps'], record['total'], record['seg'], record['util'], record['str']), flush=True)
    with log_file.open('w', encoding='utf-8') as stream:
        for record in log:
            stream.write(json.dumps(record) + '\n')
    checkpoint = out / 'checkpoint.pt'
    torch.save({'model': model.state_dict(), 'optimizer': optimizer.state_dict(), 'config': cfg,
                'step': cfg['training']['steps'], 'weather_names': WEATHER_NAMES,
                'weather_embedding_source': str(cfg['weather'].get('embeddings_file') or 'fixed_orthogonal_demo_surrogate')}, checkpoint)
    summary = {'device': str(device), 'torch_version': torch.__version__,
               'parameters': sum(p.numel() for p in model.parameters()),
               'train_samples': len(dataset), 'weather_steps': cfg['weather']['pretrain_steps'],
               'segmentation_steps': cfg['training']['steps'], 'utility_updates': utility_updates,
               'final_losses': {name: float(value.detach()) for name, value in losses.items()},
               'elapsed_seconds': round(time.time() - started, 2),
               'peak_cuda_memory_mb': round(torch.cuda.max_memory_allocated(device) / 1024 ** 2, 2)
               if device.type == 'cuda' else None,
               'checkpoint': str(checkpoint), 'status': 'training_passed'}
    (out / 'training_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print('Saved checkpoint: ' + str(checkpoint), flush=True)
    return checkpoint


def save_panel(image, label, prediction, gate, risk, path):
    rgb = (image.permute(1, 2, 0).numpy() * 255).clip(0, 255).astype(np.uint8)
    height, width = label.shape
    gate_rgb = np.stack([gate * 255, np.zeros_like(gate), (1 - gate) * 255], axis=-1).astype(np.uint8)
    risk_rgb = np.stack([risk * 255, np.zeros_like(risk), np.zeros_like(risk)], axis=-1).astype(np.uint8)
    tiles = [rgb, colorize_mask(label), colorize_mask(prediction), gate_rgb, risk_rgb]
    titles = ['RGB', 'GT', 'Prediction', 'Weather gate', 'Error risk']
    panel = Image.new('RGB', (width * len(tiles), height + 25), color=(255, 255, 255))
    draw = ImageDraw.Draw(panel)
    for index, (tile, title) in enumerate(zip(tiles, titles)):
        panel.paste(Image.fromarray(tile), (index * width, 25))
        draw.text((index * width + 4, 5), title, fill=(0, 0, 0))
    panel.save(path)


def inference(cfg, checkpoint=None, image_path=None):
    checkpoint = Path(checkpoint) if checkpoint else output_path(cfg) / 'checkpoint.pt'
    saved = torch.load(str(checkpoint), map_location='cpu')
    # Architecture and embedding dimensionality must match the saved model.
    run_cfg = copy.deepcopy(saved['config'])
    run_cfg['device'] = cfg['device']
    run_cfg['data'] = cfg['data']
    run_cfg['output_dir'] = cfg['output_dir']
    run_cfg['diffusion']['inference_steps'] = cfg['diffusion']['inference_steps']
    run_cfg['weather']['embeddings_file'] = None  # embeddings already saved in state_dict
    seed_all(run_cfg['seed'])
    device = resolve_device(run_cfg['device'])
    model = make_model(run_cfg, device)
    model.load_state_dict(saved['model'], strict=True)
    for parameter in model.weather_classifier.parameters():
        parameter.requires_grad_(False)
    model.eval()
    diffusion = CosineDiffusion(**{key: value for key, value in run_cfg['diffusion'].items()
                                  if key != 'inference_steps'}).to(device)
    out = output_path(run_cfg)
    predictions_dir = out / 'predictions'
    predictions_dir.mkdir(parents=True, exist_ok=True)
    if image_path:
        rgb = Image.open(image_path).convert('RGB')
        size = run_cfg['data']['image_size']
        height, width = (size, size) if isinstance(size, int) else size
        tensor = torch.from_numpy(np.asarray(rgb.resize((width, height), Image.Resampling.BILINEAR)).copy()).permute(2, 0, 1).float() / 255
        samples = [{'image': tensor, 'label': torch.full((height, width), 255, dtype=torch.long),
                    'image_path': str(image_path), 'weather_name': 'rgb_only'}]
    else:
        dataset = make_dataset(run_cfg, 'val')
        samples = [dataset[index] for index in range(len(dataset))]
    records = []
    started = time.time()
    with torch.no_grad():
        for index, sample in enumerate(samples):
            image = sample['image'].unsqueeze(0).to(device)
            # Only RGB is passed to the sampler. Labels are used for the panel after inference.
            output = diffusion.sample(model, image, steps=run_cfg['diffusion']['inference_steps'],
                                      seed=run_cfg['seed'] + index)
            if not torch.isfinite(output['logits']).all():
                raise RuntimeError('Non-finite DDIM output')
            prediction = output['logits'][0].argmax(0).cpu().numpy().astype(np.uint8)
            grid_h, grid_w = output['grid_size']
            def token_map(name):
                value = output[name].reshape(1, 1, grid_h, grid_w)
                return F.interpolate(value, size=prediction.shape, mode='nearest')[0, 0].cpu().numpy()
            stem = '%02d_%s' % (index, sample['weather_name'])
            Image.fromarray(prediction, mode='L').save(predictions_dir / (stem + '_trainIds.png'))
            Image.fromarray(colorize_mask(prediction)).save(predictions_dir / (stem + '_color.png'))
            save_panel(sample['image'], sample['label'].numpy(), prediction, token_map('gate'),
                       token_map('risk'), predictions_dir / (stem + '_panel.png'))
            with Image.open(sample['image_path']) as original:
                original_size = original.size
            native_prediction = Image.fromarray(prediction).resize(original_size, Image.Resampling.NEAREST)
            native_prediction.save(predictions_dir / (stem + '_native_trainIds.png'))
            routes = output['routing']
            assignments = torch.cat([r['indices'].reshape(-1) for r in routes])
            counts = torch.bincount(assignments, minlength=run_cfg['model']['num_experts']).cpu().tolist()
            record = {'image': sample['image_path'], 'weather': sample['weather_name'],
                      'weather_probabilities': dict(zip(WEATHER_NAMES, output['condition']['weather_probs'][0].cpu().tolist())),
                      'routing_assignment_counts': counts, 'gate_mean': float(output['gate'].mean()),
                      'risk_mean': float(output['risk'].mean()), 'output_size': list(prediction.shape),
                      'native_size': list(original_size), 'timesteps': output['diffusion_timesteps'],
                      'panel': str(predictions_dir / (stem + '_panel.png'))}
            records.append(record)
            print('DDIM %s: %d calls, Top-2 counts=%s' % (
                sample['weather_name'], len(record['timesteps']), counts), flush=True)
    summary = {'status': 'inference_passed', 'checkpoint': str(checkpoint),
               'samples': len(records), 'elapsed_seconds': round(time.time() - started, 2),
               'accuracy_note': 'Very short demo training; predictions are not benchmark results.',
               'records': records}
    (out / 'inference_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print('Inference outputs: ' + str(predictions_dir), flush=True)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['demo', 'train', 'infer'])
    parser.add_argument('--config', default=str(PROJECT_ROOT / 'configs/demo.yaml'))
    parser.add_argument('--device', default=None)
    parser.add_argument('--steps', type=int, default=None, help='override segmentation updates')
    parser.add_argument('--output-dir', default=None)
    parser.add_argument('--checkpoint', default=None)
    parser.add_argument('--image', default=None, help='infer one RGB image without labels or weather metadata')
    parser.add_argument('--ablation', choices=['baseline', 'weather', 'state', 'full'])
    args = parser.parse_args()
    cfg = load_config(args)
    if args.command == 'demo':
        checkpoint = train(cfg)
        inference(cfg, checkpoint=checkpoint)
    elif args.command == 'train':
        train(cfg)
    else:
        inference(cfg, checkpoint=args.checkpoint, image_path=args.image)


if __name__ == '__main__':
    main()
