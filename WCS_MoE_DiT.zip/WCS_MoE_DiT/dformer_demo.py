#!/usr/bin/env python3
"""Run the official DFormer segmentation base and its spatial WCS extension."""
import argparse
import copy
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml
from PIL import Image, ImageDraw
from torch.utils.data import DataLoader

from dformer_ext.bootstrap import build_dformer_cfg
from dformer_ext.model import WCSDFormer
from dformer_ext.losses import semantic_targets, build_criterion, wcs_losses
from wcs_moe_dit.data import ACDCDataset, WEATHER_NAMES, colorize_mask
from wcs_moe_dit.losses import utility_target

PROJECT = Path(__file__).resolve().parent


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def device_for(name):
    if name == 'auto':
        name = 'cuda' if torch.cuda.is_available() else 'cpu'
    if name.startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; use --device cpu')
    return torch.device(name)


def result_dir(config):
    path = Path(config['output_dir'])
    return path if path.is_absolute() else PROJECT / path


def configure(args):
    with open(args.config, encoding='utf-8') as stream:
        config = yaml.safe_load(stream)
    if 'extension' not in config:
        config['extension'] = {key: config['model'][key] for key in (
            'prefix_depth', 'weather_embedding_dim', 'weather_delta',
            'num_experts', 'top_k', 'enable_adapter', 'enable_weather', 'enable_state')}
    if args.device:
        config['device'] = args.device
    if args.steps is not None:
        config['training']['steps'] = args.steps
    if args.output_dir:
        config['output_dir'] = args.output_dir
    if args.ablation:
        adapter = args.ablation != 'baseline'
        config['extension']['enable_adapter'] = adapter
        config['extension']['enable_weather'] = args.ablation in ('weather', 'full')
        config['extension']['enable_state'] = args.ablation in ('state', 'full')
    if config['training']['steps'] < 1 or config['training']['utility_every'] < 1:
        raise ValueError('steps and utility_every must be positive')
    torch.set_num_threads(int(config.get('cpu_threads', 4)))
    return config


def make_model(config, device, initialize_weather=False):
    cfg = build_dformer_cfg(config, device=str(device))
    extension = copy.deepcopy(config['extension'])
    embeddings = None
    path = config['weather'].get('embeddings_file')
    if path:
        embeddings = torch.load(path, map_location='cpu')
        if not torch.is_tensor(embeddings) or embeddings.ndim != 2 or embeddings.shape[0] != 4:
            raise ValueError('Expected [4,D] tensor for weather embeddings')
        extension['weather_embedding_dim'] = embeddings.shape[1]
        config['extension']['weather_embedding_dim'] = embeddings.shape[1]
    model = WCSDFormer(cfg, **extension)
    model.criterion = build_criterion(
        num_classes=cfg.MODEL.SEM_SEG_HEAD.NUM_CLASSES,
        decoder_layers=cfg.MODEL.DFORMER.DEC_LAYERS,
        num_points=cfg.MODEL.DFORMER.TRAIN_NUM_POINTS,
        eos_coef=cfg.MODEL.DFORMER.NO_OBJECT_WEIGHT,
        oversample_ratio=cfg.MODEL.DFORMER.OVERSAMPLE_RATIO,
        importance_sample_ratio=cfg.MODEL.DFORMER.IMPORTANCE_SAMPLE_RATIO)
    if embeddings is not None:
        model.set_weather_text_embeddings(embeddings)
    if initialize_weather:
        weights = Path(config['weather'].get('imagenet_checkpoint') or '')
        if weights.is_file():
            state = torch.load(str(weights), map_location='cpu')
            state = {key: value for key, value in state.items() if not key.startswith('fc.')}
            missing, unexpected = model.weather_classifier.load_state_dict(state, strict=False)
            if set(missing) != {'fc.weight', 'fc.bias'} or unexpected:
                raise RuntimeError('Unexpected weather-classifier checkpoint mismatch')
            print('Weather: initialized local ImageNet ResNet-18 trunk.', flush=True)
    return model.to(device), cfg


def dataset(config, split, augment=False):
    return ACDCDataset(root=config['data']['root'], split=split,
                       image_size=config['data']['image_size'],
                       limit_per_weather=config['data'][split + '_limit_per_weather'],
                       augment=augment)


def infinite(loader):
    while True:
        yield from loader


def train(config):
    seed_all(config['seed'])
    device = device_for(config['device'])
    output_dir = result_dir(config)
    output_dir.mkdir(parents=True, exist_ok=True)
    train_data = dataset(config, 'train', augment=True)
    batch_size = min(config['training']['batch_size'], len(train_data))
    if batch_size < 2 and config['weather']['pretrain_steps']:
        raise ValueError('Weather pretraining uses BatchNorm; choose batch_size >= 2')
    loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=0,
                        drop_last=True)
    batches = infinite(loader)
    model, cfg = make_model(config, device, initialize_weather=True)
    print('Official DFormer: ResNet-50 + %d deformable pixel layers + %d query layers; width=%d Q=%d' % (
        cfg.MODEL.SEM_SEG_HEAD.TRANSFORMER_ENC_LAYERS, model.base.sem_seg_head.predictor.num_layers,
        cfg.MODEL.DFORMER.HIDDEN_DIM, cfg.MODEL.DFORMER.NUM_OBJECT_QUERIES), flush=True)
    print('Device=%s; data=%d ACDC images; extension=%s' % (
        device, len(train_data), config['extension']), flush=True)
    if device.type == 'cuda':
        print('GPU=' + torch.cuda.get_device_name(device), flush=True)
        torch.cuda.reset_peak_memory_stats(device)
    started = time.time()
    records = []
    weather_optimizer = torch.optim.AdamW(model.weather_classifier.parameters(),
                                         lr=config['weather']['learning_rate'])
    model.weather_classifier.requires_grad_(True)
    model.weather_classifier.train()
    for step in range(config['weather']['pretrain_steps']):
        batch = next(batches)
        images = batch['image'].to(device)
        images = (images - images.new_tensor([0.485, 0.456, 0.406])[None, :, None, None]) / images.new_tensor(
            [0.229, 0.224, 0.225])[None, :, None, None]
        loss = F.cross_entropy(model.weather_classifier(images), batch['weather'].to(device))
        weather_optimizer.zero_grad(set_to_none=True)
        loss.backward()
        weather_optimizer.step()
        records.append({'phase': 'weather', 'step': step + 1, 'loss': float(loss.detach())})
        print('Weather %d/%d: %.4f' % (step + 1, config['weather']['pretrain_steps'], float(loss)), flush=True)
    model.weather_classifier.requires_grad_(False)
    model.train()
    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),
                                  lr=config['training']['learning_rate'],
                                  weight_decay=config['training']['weight_decay'])
    utility_updates = 0
    mix = torch.tensor(config['training']['weather_probability_mix'], dtype=torch.float, device=device)
    if mix.shape != (3,) or (mix < 0).any() or not torch.isclose(mix.sum(), mix.new_tensor(1.0)):
        raise ValueError('weather_probability_mix needs three probabilities summing to one')
    for step in range(config['training']['steps']):
        batch = next(batches)
        images, labels = batch['image'].to(device), batch['label'].to(device)
        targets = semantic_targets(labels)
        masks, timesteps = [], []
        for target in targets:
            noisy_mask, _, timestep = model.base.prepare_diffusion_concat(target['masks'])
            masks.append(noisy_mask)
            timesteps.append(timestep)
        noise_masks = torch.stack(masks)
        timestep = torch.cat(timesteps)
        condition = model.encode_condition(images)
        probabilities = condition['weather_probs'].clone()
        choices = torch.multinomial(mix, images.shape[0], replacement=True)
        incorrect = (batch['weather'].to(device) + torch.randint(1, 4, (images.shape[0],), device=device)) % 4
        probabilities = torch.where((choices == 1)[:, None], F.one_hot(incorrect, 4).float(), probabilities)
        probabilities = torch.where((choices == 2)[:, None], torch.full_like(probabilities, 0.25), probabilities)
        condition['weather_probs'] = probabilities
        condition['weather_vector'] = model.weather_projection(probabilities @ model.weather_embeddings)
        prefix = model.prepare_prefix(noise_masks, timestep, condition)
        scheduled = (config['extension']['enable_adapter'] and config['extension']['enable_weather']
                     and step >= config['training']['utility_start']
                     and (step - config['training']['utility_start']) % config['training']['utility_every'] == 0)
        utility = None
        if scheduled:
            with torch.no_grad():
                on = model.decode_suffix(prefix, weather_gate_override=1.0)
                off = model.decode_suffix(prefix, weather_gate_override=0.0)
                utility = utility_target(on['logits'], off['logits'], labels, prefix['grid_size'],
                                         config['training']['utility_temperature'])
            utility_updates += 1
        output = model.decode_suffix(prefix)
        # Use actual upstream Hungarian + classification/BCE/Dice deep-supervision losses.
        base_output = {key: output[key] for key in ('pred_logits', 'pred_masks', 'aux_outputs')}
        base_losses = model.criterion(base_output, targets)
        weighted_base = {key: value * model.criterion.weight_dict[key] for key, value in base_losses.items()
                         if key in model.criterion.weight_dict}
        base_total = sum(weighted_base.values())
        alpha = model.base.alphas_cumprod[timestep].float()
        extension_losses = wcs_losses(output, labels, alpha, utility=utility,
                                      enable_weather=config['extension']['enable_weather'],
                                      enable_state=config['extension']['enable_state'],
                                      spatial_moe_enabled=config['extension']['enable_adapter'])
        total = base_total + extension_losses['total_wcs']
        if not torch.isfinite(total):
            raise RuntimeError('Non-finite DFormer training loss')
        optimizer.zero_grad(set_to_none=True)
        total.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config['training']['grad_clip'])
        if not torch.isfinite(grad_norm):
            raise RuntimeError('Non-finite DFormer gradients')
        optimizer.step()
        record = {'phase': 'dformer', 'step': step + 1, 'total': float(total.detach()),
                  'base_total': float(base_total.detach()),
                  'base_losses': {key: float(value.detach()) for key, value in weighted_base.items()},
                  'wcs_losses': {key: float(value.detach()) for key, value in extension_losses.items()},
                  'grad_norm': float(grad_norm), 'utility_scheduled': bool(scheduled),
                  'timesteps': timestep.tolist()}
        records.append(record)
        print('DFormer %d/%d: base=%.4f WCS=%.4f utility=%s' % (
            step + 1, config['training']['steps'], record['base_total'],
            record['wcs_losses']['total_wcs'], scheduled), flush=True)
    checkpoint = output_dir / 'checkpoint.pt'
    torch.save({'model': model.state_dict(), 'optimizer': optimizer.state_dict(), 'config': config,
                'step': config['training']['steps'],
                'upstream': {'repository': 'https://github.com/cp3wan/DFormer',
                             'commit': '14f8d9cb8f6dde33a2487a5d611c40903ba79669'},
                'model_type': 'official_dformer_with_spatial_wcs_adapter'}, checkpoint)
    (output_dir / 'train_log.jsonl').write_text(''.join(json.dumps(record) + '\n' for record in records))
    summary = {'status': 'training_passed', 'device': str(device), 'checkpoint': str(checkpoint),
               'parameters': sum(p.numel() for p in model.parameters()),
               'train_samples': len(train_data), 'steps': config['training']['steps'],
               'utility_updates': utility_updates, 'elapsed_seconds': round(time.time() - started, 2),
               'peak_cuda_memory_mb': round(torch.cuda.max_memory_allocated(device) / 1024 ** 2, 2)
               if device.type == 'cuda' else None, 'final_record': records[-1],
               'backbone_initialization': 'random; no DFormer/R50 pretrained checkpoint requested',
               'weather_embedding_source': config['weather'].get('embeddings_file') or 'fixed_orthogonal_surrogate'}
    (output_dir / 'training_summary.json').write_text(json.dumps(summary, indent=2))
    (output_dir / 'resolved_dformer_config.yaml').write_text(cfg.dump())
    print('Saved ' + str(checkpoint), flush=True)
    return checkpoint


def panel(sample, prediction, gate, risk, path, enable_adapter=True):
    rgb = (sample['image'].permute(1, 2, 0).numpy() * 255).clip(0, 255).astype(np.uint8)
    height, width = prediction.shape
    tiles = [rgb, colorize_mask(sample['label'].numpy()), colorize_mask(prediction),
             np.stack([gate * 255, gate * 0, (1 - gate) * 255], -1).astype(np.uint8),
             np.stack([risk * 255, risk * 0, risk * 0], -1).astype(np.uint8)]
    image = Image.new('RGB', (width * 5, height + 25), 'white')
    draw = ImageDraw.Draw(image)
    caption = 'DFormer + WCS' if enable_adapter else 'DFormer'
    for index, (tile, text) in enumerate(zip(tiles, ['RGB', 'GT', caption, 'Weather gate', 'Error risk'])):
        image.paste(Image.fromarray(tile), (index * width, 25))
        draw.text((index * width + 3, 5), text, fill='black')
    image.save(path)


def restore_inference_config(checkpoint_config, requested_config):
    saved_config = copy.deepcopy(checkpoint_config)
    saved_config['device'] = requested_config['device']
    saved_config['output_dir'] = requested_config['output_dir']
    saved_config['data'] = copy.deepcopy(requested_config['data'])
    # SNR scale is a plain model attribute rather than a state_dict buffer.
    # Restore the trained corruption configuration; only sampling choices vary.
    for key in ('inference_steps', 'eta'):
        saved_config['diffusion'][key] = requested_config['diffusion'][key]
    saved_config['weather']['embeddings_file'] = None
    return saved_config


def infer(config, checkpoint=None, image_path=None):
    checkpoint = Path(checkpoint) if checkpoint else result_dir(config) / 'checkpoint.pt'
    state = torch.load(str(checkpoint), map_location='cpu')
    saved_config = restore_inference_config(state['config'], config)
    seed_all(saved_config['seed'])
    device = device_for(saved_config['device'])
    model, _ = make_model(saved_config, device)
    model.load_state_dict(state['model'], strict=True)
    model.eval()
    directory = result_dir(saved_config)
    predictions = directory / 'predictions'
    predictions.mkdir(parents=True, exist_ok=True)
    if image_path:
        size = saved_config['data']['image_size']
        height, width = (size, size) if isinstance(size, int) else size
        with Image.open(image_path) as image:
            resized = np.asarray(image.convert('RGB').resize((width, height), Image.Resampling.BILINEAR)).copy()
        tensor = torch.from_numpy(resized).permute(2, 0, 1).float() / 255
        samples = [{'image': tensor, 'label': torch.full((height, width), 255, dtype=torch.long),
                    'image_path': str(image_path), 'weather_name': 'rgb_only'}]
    else:
        val_data = dataset(saved_config, 'val')
        samples = [val_data[index] for index in range(len(val_data))]
    records = []
    started = time.time()
    with torch.no_grad():
        for index, sample in enumerate(samples):
            output = model.sample(sample['image'].unsqueeze(0).to(device),
                                  steps=saved_config['diffusion']['inference_steps'],
                                  seed=saved_config['seed'] + index,
                                  eta=saved_config['diffusion']['eta'])
            if not torch.isfinite(output['logits']).all():
                raise RuntimeError('Non-finite DFormer inference output')
            prediction = output['logits'][0].argmax(0).cpu().numpy().astype(np.uint8)
            grid = output['grid_size']
            def token_map(name):
                value = output[name].reshape(1, 1, *grid)
                return F.interpolate(value, size=prediction.shape, mode='nearest')[0, 0].cpu().numpy()
            stem = '%02d_%s' % (index, sample['weather_name'])
            Image.fromarray(prediction).save(predictions / (stem + '_trainIds.png'))
            Image.fromarray(colorize_mask(prediction)).save(predictions / (stem + '_color.png'))
            panel(sample, prediction, token_map('gate'), token_map('risk'), predictions / (stem + '_panel.png'),
                  enable_adapter=saved_config['extension']['enable_adapter'])
            with Image.open(sample['image_path']) as original:
                native = original.size
            Image.fromarray(prediction).resize(native, Image.Resampling.NEAREST).save(
                predictions / (stem + '_native_trainIds.png'))
            routes = output['routing']
            counts = torch.bincount(torch.cat([r['indices'].reshape(-1) for r in routes]), minlength=4).cpu().tolist() if routes else []
            records.append({'weather': sample['weather_name'], 'image_path': sample['image_path'],
                            'timesteps': output['diffusion_timesteps'], 'queries': model.base.num_queries,
                            'diffusion_trace': output['diffusion_trace'],
                            'weather_probabilities': dict(zip(WEATHER_NAMES, output['condition']['weather_probs'][0].cpu().tolist())),
                            'routing_assignment_counts': counts, 'gate_mean': float(output['gate'].mean()),
                            'risk_mean': float(output['risk'].mean()), 'panel': str(predictions / (stem + '_panel.png'))})
            print('DFormer DDIM %s: %d steps, %d query masks, routes=%s' % (
                sample['weather_name'], len(output['diffusion_timesteps']), model.base.num_queries, counts), flush=True)
    summary = {'status': 'inference_passed', 'samples': len(records), 'records': records,
               'elapsed_seconds': round(time.time() - started, 2), 'checkpoint': str(checkpoint),
               'device': str(device), 'accuracy_note': 'Smoke run with random segmentation initialization; not an accuracy reproduction.'}
    (directory / 'inference_summary.json').write_text(json.dumps(summary, indent=2))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['demo', 'train', 'infer'])
    parser.add_argument('--config', default=str(PROJECT / 'configs/dformer_demo.yaml'))
    parser.add_argument('--device', default=None)
    parser.add_argument('--steps', type=int, default=None)
    parser.add_argument('--output-dir', default=None)
    parser.add_argument('--checkpoint', default=None)
    parser.add_argument('--image', default=None)
    parser.add_argument('--ablation', choices=['baseline', 'moe', 'weather', 'state', 'full'])
    args = parser.parse_args()
    config = configure(args)
    if args.command == 'demo':
        checkpoint = train(config)
        infer(config, checkpoint)
    elif args.command == 'train':
        train(config)
    else:
        infer(config, args.checkpoint, args.image)


if __name__ == '__main__':
    main()
