"""ACDC validity support for the official DFormer set loss, plus WCS losses.

The matcher and criterion inherit DFormer's classification and auxiliary-layer
workflow.  The only change to the mask objectives is that sampling is restricted
to centers of annotated pixels, including the uncertainty sampling candidates.
"""

from typing import Dict, List

import torch
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment

from .bootstrap import ensure_bootstrap

ensure_bootstrap()

from dformer.modeling.criterion import SetCriterion, dice_loss_jit, sigmoid_ce_loss_jit
from dformer.modeling.matcher import HungarianMatcher, batch_dice_loss_jit, batch_sigmoid_ce_loss_jit
from detectron2.projects.point_rend.point_features import point_sample

from wcs_moe_dit.losses import masked_cross_entropy, risk_target, structure_loss, load_balance_loss


def semantic_targets(labels: torch.Tensor, num_classes: int = 19) -> List[Dict[str, torch.Tensor]]:
    """Convert [B,H,W] labels to unique-class masks and an explicit valid map."""
    if labels.ndim != 3:
        raise ValueError("Semantic labels must have shape [B,H,W]")
    result = []
    for image_labels in labels:
        valid = (image_labels >= 0) & (image_labels < num_classes)
        classes = torch.unique(image_labels[valid]).long()
        masks = (image_labels.unsqueeze(0) == classes[:, None, None]) & valid.unsqueeze(0)
        result.append({"labels": classes, "masks": masks.float(), "valid": valid})
    return result


def _valid_centers(target: Dict, device):
    valid = target["valid"].to(device=device, dtype=torch.bool)
    if valid.ndim != 2 or tuple(valid.shape) != tuple(target["masks"].shape[-2:]):
        raise ValueError("Target valid map and masks must have the same H,W")
    return valid, valid.flatten().nonzero(as_tuple=False).squeeze(1)


def _sample_indices(valid_indices: torch.Tensor, count: int, rows: int):
    # A zero point count requests an exhaustive pass, useful for small inputs.
    if count <= 0:
        return valid_indices.unsqueeze(0).expand(rows, -1)
    offsets = torch.randint(valid_indices.numel(), (rows, count), device=valid_indices.device)
    return valid_indices[offsets]


def _point_coords(indices: torch.Tensor, spatial_shape):
    height, width = spatial_shape
    x = (indices.remainder(width).float() + 0.5) / width
    y = (torch.div(indices, width, rounding_mode="floor").float() + 0.5) / height
    return torch.stack((x, y), dim=-1)


def _source_at_centers(masks: torch.Tensor, indices: torch.Tensor, target_shape):
    if tuple(masks.shape[-2:]) == tuple(target_shape):
        # Bilinear sampling at exact pixel centers equals gathering.  Gathering
        # avoids floating-point grid drift into an ignored neighboring pixel.
        return masks.flatten(1).gather(1, indices)
    return point_sample(masks[:, None], _point_coords(indices, target_shape),
                        align_corners=False).squeeze(1)


class ValidHungarianMatcher(HungarianMatcher):
    """Original matching costs evaluated only at valid ground-truth centers."""

    @torch.no_grad()
    def memory_efficient_forward(self, outputs, targets):
        batch_size, num_queries = outputs["pred_logits"].shape[:2]
        assignments = []
        for batch_index in range(batch_size):
            target = targets[batch_index]
            mask_logits = outputs["pred_masks"][batch_index]
            valid, valid_indices = _valid_centers(target, mask_logits.device)
            if not target["labels"].numel() or not valid_indices.numel() or not num_queries:
                empty = torch.empty(0, dtype=torch.int64)
                assignments.append((empty, empty.clone()))
                continue
            class_probs = outputs["pred_logits"][batch_index].float().softmax(-1)
            classes = target["labels"].to(class_probs.device)
            class_cost = -class_probs[:, classes]
            shared_indices = _sample_indices(valid_indices, self.num_points, 1)
            source_points = _source_at_centers(mask_logits.float(), shared_indices.expand(num_queries, -1), valid.shape)
            target_masks = target["masks"].to(device=mask_logits.device, dtype=torch.float32)
            target_points = target_masks.flatten(1)[:, shared_indices[0]]
            mask_cost = batch_sigmoid_ce_loss_jit(source_points, target_points)
            dice_cost = batch_dice_loss_jit(source_points, target_points)
            cost = self.cost_class * class_cost + self.cost_mask * mask_cost + self.cost_dice * dice_cost
            source_index, target_index = linear_sum_assignment(cost.cpu().numpy())
            assignments.append((torch.as_tensor(source_index, dtype=torch.int64),
                                torch.as_tensor(target_index, dtype=torch.int64)))
        return assignments


class ValidSetCriterion(SetCriterion):
    """Keep DFormer class CE and deep supervision, exclude ignored mask pixels."""

    def loss_masks(self, outputs, targets, indices, num_masks):
        prediction = outputs["pred_masks"]
        zero = prediction.sum() * 0.0
        mask_loss, dice_loss = zero, zero
        for batch_index, (source_index, target_index) in enumerate(indices):
            if not source_index.numel():
                continue
            target = targets[batch_index]
            valid, valid_indices = _valid_centers(target, prediction.device)
            if not valid_indices.numel():
                continue
            source_masks = prediction[batch_index, source_index.to(prediction.device)].float()
            target_masks = target["masks"].to(source_masks)[target_index.to(prediction.device)]
            matched_count = source_masks.shape[0]
            with torch.no_grad():
                if self.num_points <= 0:
                    selected_indices = _sample_indices(valid_indices, 0, matched_count)
                else:
                    candidate_count = max(self.num_points, int(self.num_points * self.oversample_ratio))
                    candidate_indices = _sample_indices(valid_indices, candidate_count, matched_count)
                    candidate_logits = _source_at_centers(source_masks, candidate_indices, valid.shape)
                    important_count = min(self.num_points, int(self.num_points * self.importance_sample_ratio))
                    if important_count:
                        uncertain = (-candidate_logits.abs()).topk(important_count, dim=1).indices
                        important_indices = candidate_indices.gather(1, uncertain)
                    else:
                        important_indices = candidate_indices[:, :0]
                    if self.num_points > important_count:
                        random_indices = _sample_indices(valid_indices, self.num_points - important_count, matched_count)
                    else:
                        random_indices = important_indices[:, :0]
                    selected_indices = torch.cat((important_indices, random_indices), dim=1)
                # Ground-truth centers are indexed exactly; no soft labels can
                # be interpolated from ignored or differently annotated pixels.
                point_labels = target_masks.flatten(1).gather(1, selected_indices)
            point_logits = _source_at_centers(source_masks, selected_indices, valid.shape)
            mask_loss = mask_loss + sigmoid_ce_loss_jit(point_logits, point_labels, num_masks)
            dice_loss = dice_loss + dice_loss_jit(point_logits, point_labels, num_masks)
        return {"loss_mask": mask_loss, "loss_dice": dice_loss}


def build_criterion(num_classes=19, decoder_layers=10, num_points=12544,
                    eos_coef=0.1, oversample_ratio=3.0, importance_sample_ratio=0.75):
    """Official weights: class CE 2, mask BCE 5, Dice 5, including deep outputs."""
    weights = {"loss_ce": 2.0, "loss_mask": 5.0, "loss_dice": 5.0}
    for index in range(max(0, int(decoder_layers) - 1)):
        weights.update({"loss_ce_%d" % index: 2.0, "loss_mask_%d" % index: 5.0,
                        "loss_dice_%d" % index: 5.0})
    matcher = ValidHungarianMatcher(cost_class=2.0, cost_mask=5.0, cost_dice=5.0,
                                   num_points=num_points)
    return ValidSetCriterion(num_classes, matcher, weights, eos_coef, ["labels", "masks"],
                             num_points, oversample_ratio, importance_sample_ratio)


def _masked_bce(prediction, target, valid):
    values = F.binary_cross_entropy(prediction.float().clamp(1e-6, 1 - 1e-6),
                                   target.detach().float(), reduction="none")
    weight = valid.to(values.dtype)
    return (values * weight).sum() / weight.sum().clamp_min(1.0)


def wcs_losses(output, labels, alpha_bar, utility=None, enable_weather=True,
               enable_state=True, spatial_moe_enabled=True):
    """Add WCS supervision to DFormer's original query-set loss.

    Common prefix and risk heads retain supervision for all adapted MoE
    ablations; state disabling removes state routing and structural loss.
    The untouched DFormer baseline has no adapter and receives no WCS losses.
    """
    reference = output["logits"] if "logits" in output else output["pred_masks"]
    zero = reference.sum() * 0.0
    result = {name: zero for name in ("pre", "err", "util", "str", "bal")}
    if spatial_moe_enabled:
        result["pre"] = masked_cross_entropy(output["pre_logits"], labels)
        target_risk, valid = risk_target(output["pre_logits"], labels, output["grid_size"])
        result["err"] = _masked_bce(output["risk"], target_risk, valid)
        if enable_weather and utility is not None:
            result["util"] = _masked_bce(output["gate"], utility[0], utility[1])
        if enable_state:
            result["str"] = structure_loss(output["routing"], labels, output["risk"],
                                           output["grid_size"], alpha_bar)
        if output["routing"]:
            result["bal"] = load_balance_loss(output["routing"])
    result["total_wcs"] = (0.4 * result["pre"] + 0.1 * result["err"] + 0.1 * result["util"]
                            + 0.01 * result["str"] + 0.01 * result["bal"])
    return result
