"""Load vendored DFormer with the user's existing Detectron2 dependencies."""

import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OFFICIAL_ROOT = PROJECT_ROOT / "third_party" / "DFormer"


def ensure_bootstrap():
    paths = [
        OFFICIAL_ROOT,
        Path("/home/neu/command/_deps/hg"),
        Path("/home/neu/command/_deps/mmcv1"),
        Path("/home/neu/command/_deps/common"),
    ]
    for path in reversed(paths):
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
    try:
        import detectron2
    except ImportError as error:
        raise ImportError("Use conda openpcdet; the existing /home/neu/command/_deps/hg Detectron2 dependencies are required") from error
    return {"official_root": str(OFFICIAL_ROOT), "detectron2": detectron2.__version__}


def build_dformer_cfg(settings, device="cpu"):
    """Merge the actual official ADE20K/R50 config, then adapt it to ACDC."""
    ensure_bootstrap()
    from detectron2.config import get_cfg
    from detectron2.projects.deeplab import add_deeplab_config
    from dformer import add_DFormer_config

    model = settings.get("model", settings)
    diffusion = settings.get("diffusion", {})
    width = int(model.get("width", 256))
    if width != 256:
        raise ValueError("Use width=256: the official DFormer query aggregation hardcodes this published width")
    if int(diffusion.get("training_steps", 1000)) != 1000:
        raise ValueError("The official DFormer diffusion process uses 1000 training timesteps")
    cfg = get_cfg()
    add_deeplab_config(cfg)
    add_DFormer_config(cfg)
    config_file = model.get("official_config", "third_party/DFormer/configs/ade20k/semantic-segmentation/dformer_R50_bs16_160k.yaml")
    config_path = Path(config_file)
    if not config_path.is_absolute():
        config_path = PROJECT_ROOT / config_path
    cfg.merge_from_file(str(config_path))
    cfg.MODEL.WEIGHTS = ""  # No network requests or implicit checkpoint downloads.
    cfg.MODEL.DEVICE = str(device)
    cfg.MODEL.SEM_SEG_HEAD.NUM_CLASSES = int(model.get("num_classes", 19))
    cfg.MODEL.SEM_SEG_HEAD.TRANSFORMER_ENC_LAYERS = int(model.get("pixel_encoder_layers", 6))
    cfg.MODEL.SEM_SEG_HEAD.DEFORMABLE_TRANSFORMER_ENCODER_N_HEADS = int(model.get("num_heads", 8))
    cfg.MODEL.SEM_SEG_HEAD.CONVS_DIM = width
    cfg.MODEL.SEM_SEG_HEAD.MASK_DIM = width
    cfg.MODEL.DFORMER.HIDDEN_DIM = width
    cfg.MODEL.DFORMER.NUM_OBJECT_QUERIES = int(model.get("num_queries", 100))
    cfg.MODEL.DFORMER.NHEADS = int(model.get("num_heads", 8))
    cfg.MODEL.DFORMER.DIM_FEEDFORWARD = int(model.get("ffn_dim", 2048))
    cfg.MODEL.DFORMER.DEC_LAYERS = int(model.get("prefix_depth", 3)) + int(model.get("suffix_depth", 6)) + 1
    cfg.MODEL.DFORMER.TRAIN_NUM_POINTS = int(model.get("num_points", 1024))
    cfg.MODEL.DFORMER.SNR_SCALE = float(diffusion.get("snr_scale", 0.1))
    cfg.MODEL.DFORMER.SAMPLE_STEP = int(diffusion.get("inference_steps", 4))
    cfg.MODEL.DFORMER.DROPOUT = 0.0
    cfg.MODEL.DFORMER.TEST.SEMANTIC_ON = True
    cfg.MODEL.DFORMER.TEST.INSTANCE_ON = False
    cfg.MODEL.DFORMER.TEST.PANOPTIC_ON = False
    cfg.DATASETS.TRAIN = ("acdc_wcs_demo_train",)
    cfg.DATASETS.TEST = ("acdc_wcs_demo_val",)
    return cfg
