"""WCS extensions to the official DFormer diffusion segmentation baseline."""
