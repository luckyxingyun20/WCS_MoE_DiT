"""Spatial weather/state MoE adapters on the actual official DFormer model.

The baseline model, backbone, deformable pixel decoder, masked-query decoder
layers, prediction heads, Hungarian criterion and Gaussian mask diffusion are
imported from the vendored upstream source. Only the query-loop orchestration
is split so one dense prefix can be reused by the learned/ON/OFF spatial suffix.
The spatial adapter is an explicit extension to DFormer, not an original
DFormer component. Weather text vectors default to declared category surrogates.
"""

import math
from typing import Dict, Optional

import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import resnet18

from .bootstrap import ensure_bootstrap

ensure_bootstrap()
from dformer.DFormer_model import DFormer
from dformer.modeling.transformer_decoder.dformer_transformer_decoder import MultiScaleMaskedTransformerDecoder


WEATHER_CLASSES = ("fog", "night", "rain", "snow")


class Projection(nn.Sequential):
    def __init__(self, input_width, output_width):
        super().__init__(nn.Linear(input_width, output_width), nn.LayerNorm(output_width), nn.GELU())


class ExpertFFN(nn.Sequential):
    def __init__(self, width, hidden):
        super().__init__(nn.Linear(width, hidden), nn.GELU(), nn.Linear(hidden, width))


class SpatialMoE(nn.Module):
    """Four routed FFNs evaluated only on their Top-2 selected spatial cells."""

    def __init__(self, width, num_experts=4, top_k=2, delta=1.0,
                 enable_weather=True, enable_state=True):
        super().__init__()
        if not 1 <= top_k <= num_experts or delta <= 0:
            raise ValueError("top_k and weather_delta must be valid and positive")
        self.top_k = top_k
        self.delta = delta
        self.enable_weather = enable_weather
        self.enable_state = enable_state
        router_width = width // 2
        self.visual_inputs = nn.ModuleList([Projection(width, router_width) for _ in range(3)])
        self.visual_router = nn.Linear(router_width * 3, num_experts)
        self.weather_inputs = nn.ModuleList([Projection(width, router_width) for _ in range(4)])
        self.weather_router = nn.Linear(router_width * 4, num_experts)
        self.state_input = Projection(3, router_width)
        self.state_time = Projection(width, router_width)
        self.state_router = nn.Linear(router_width * 2, num_experts)
        self.experts = nn.ModuleList([ExpertFFN(width, width * 4) for _ in range(num_experts)])
        self.shared_expert = ExpertFFN(width, width * 2)
        self.norm = nn.LayerNorm(width)

    def forward(self, tokens, image_tokens, time, weather, gate, state):
        batch, count, width = tokens.shape
        time_tokens = time[:, None].expand(-1, count, -1)
        weather_tokens = weather[:, None].expand(-1, count, -1)
        current = self.norm(tokens)
        visual = (current, image_tokens, time_tokens)
        scores = self.visual_router(torch.cat([
            projection(value) for projection, value in zip(self.visual_inputs, visual)
        ], dim=-1))
        if self.enable_weather:
            weather_inputs = visual + (weather_tokens,)
            weather_scores = self.weather_router(torch.cat([
                projection(value) for projection, value in zip(self.weather_inputs, weather_inputs)
            ], dim=-1)).tanh() * self.delta
            scores = scores + gate[..., None] * weather_scores
        if self.enable_state:
            scores = scores + self.state_router(torch.cat((
                self.state_input(state.detach()), self.state_time(time_tokens),
            ), dim=-1))
        probabilities = scores.softmax(-1)
        weights, indices = probabilities.topk(self.top_k, dim=-1)
        weights = weights / weights.sum(-1, keepdim=True).clamp_min(1e-8)
        flat = current.reshape(-1, width)
        flat_indices = indices.reshape(-1, self.top_k)
        flat_weights = weights.reshape(-1, self.top_k)
        routed = torch.zeros_like(flat)
        for expert_index, expert in enumerate(self.experts):
            token_ids, slots = torch.where(flat_indices == expert_index)
            if token_ids.numel():
                transformed = expert(flat.index_select(0, token_ids))
                routed.index_add_(0, token_ids, transformed * flat_weights[token_ids, slots, None])
        output = tokens + routed.reshape(batch, count, width) + self.shared_expert(current)
        return output, {"probs": probabilities, "indices": indices, "weights": weights}


class SplitDFormerDecoder(MultiScaleMaskedTransformerDecoder):
    """Inherited upstream layers/heads with a prefix/suffix execution boundary."""

    def __init__(self, cfg, prefix_depth=3):
        arguments = MultiScaleMaskedTransformerDecoder.from_config(
            cfg, cfg.MODEL.SEM_SEG_HEAD.CONVS_DIM, mask_classification=True
        )
        super().__init__(**arguments)
        if not 1 <= prefix_depth < self.num_layers:
            raise ValueError("prefix_depth must leave at least one original query layer in the suffix")
        self.prefix_depth = prefix_depth

    def initialize_queries(self, multi_scale, mask_features, noise_masks, timestep):
        # These operations preserve the upstream forward() query initialization.
        src, pos, sizes = [], [], []
        time = self.time_mlp(timestep)
        for index in range(self.num_feature_levels):
            sizes.append(multi_scale[index].shape[-2:])
            position = self.pe_layer(multi_scale[index], None).flatten(2)
            source = self.input_proj[index](multi_scale[index]).flatten(2)
            source = source + self.level_embed.weight[index][None, :, None]
            src.append(source.permute(2, 0, 1))
            pos.append(position.permute(2, 0, 1))
        batch = src[0].shape[1]
        noisy = F.interpolate(noise_masks, mask_features.shape[-2:], mode="bilinear", align_corners=False)
        noisy = noisy.flatten(2).to(torch.float64)
        pixels = mask_features.flatten(2).permute(0, 2, 1).to(torch.float64)
        denominator = noisy.sum(2).unsqueeze(2)
        denominator[denominator == 0] = 1
        denominator = denominator.repeat(1, 1, 256)  # Published upstream width.
        output = (torch.einsum("bqs,bsc->bqc", noisy, pixels) / denominator).permute(1, 0, 2).float()
        query_embed = self.query_embed.weight.unsqueeze(1).repeat(1, batch, 1)
        attention_mask = F.interpolate(noise_masks, sizes[0], mode="bilinear", align_corners=False)
        attention_mask = (
            attention_mask.flatten(2).unsqueeze(1).repeat(1, self.num_heads, 1, 1).flatten(0, 1) < 0.5
        ).bool().detach()
        return {"output": output, "src": src, "pos": pos, "sizes": sizes,
                "time": time, "query_embed": query_embed, "attention_mask": attention_mask,
                "predictions_class": [], "predictions_mask": []}

    def run_layer(self, context, layer, mask_features, memory_residual=None):
        level = layer % self.num_feature_levels
        attention_mask = context["attention_mask"].clone()
        attention_mask[torch.where(attention_mask.sum(-1) == attention_mask.shape[-1])] = False
        memory = context["src"][level]
        if memory_residual is not None:
            residual = F.interpolate(memory_residual, context["sizes"][level], mode="bilinear", align_corners=False)
            memory = memory + residual.flatten(2).permute(2, 0, 1)
        output = self.transformer_cross_attention_layers[layer](
            context["output"], memory, memory_mask=attention_mask,
            memory_key_padding_mask=None, pos=context["pos"][level], query_pos=context["query_embed"],
        )
        output = self.transformer_self_attention_layers[layer](
            output, tgt_mask=None, tgt_key_padding_mask=None, query_pos=context["query_embed"],
        )
        output = self.transformer_ffn_layers[layer](output)
        scale_shift = self.block_time_mlp(context["time"]).unsqueeze(0).float()
        scale_shift = torch.repeat_interleave(scale_shift, self.num_queries, dim=0)
        scale, shift = scale_shift.chunk(2, dim=2)
        output = output * (scale + 1) + shift
        classes, masks, attention_mask = self.forward_prediction_heads(
            output, mask_features, context["sizes"][(layer + 1) % self.num_feature_levels]
        )
        context["output"] = output
        context["attention_mask"] = attention_mask
        context["predictions_class"].append(classes)
        context["predictions_mask"].append(masks)
        return context

    def prepare_prefix(self, multi_scale, mask_features, noise_masks, timestep):
        context = self.initialize_queries(multi_scale, mask_features, noise_masks, timestep)
        for layer in range(self.prefix_depth):
            self.run_layer(context, layer, mask_features)
        return context

    @staticmethod
    def copy_context(context):
        # Suffix candidates share tensor values but own lists and attention-mask updates.
        copied = dict(context)
        copied["predictions_class"] = list(context["predictions_class"])
        copied["predictions_mask"] = list(context["predictions_mask"])
        return copied

    def pack_predictions(self, context):
        return {
            "pred_logits": context["predictions_class"][-1],
            "pred_masks": context["predictions_mask"][-1],
            "aux_outputs": self._set_aux_loss(context["predictions_class"], context["predictions_mask"]),
        }


def semantic_scores(class_logits, mask_logits):
    """The upstream semantic_inference class/mask fusion, with batch support."""
    classes = class_logits.softmax(-1)[..., :-1]
    return torch.einsum("bqc,bqhw->bchw", classes, mask_logits.sigmoid())


def semantic_logits(scores, padded_size, image_size):
    scores = F.interpolate(scores, padded_size, mode="bilinear", align_corners=False)
    scores = scores[:, :, :image_size[0], :image_size[1]]
    # Log-normalization enables CE/utility supervision, preserving upstream argmax.
    probabilities = scores / scores.sum(1, keepdim=True).clamp_min(1e-8)
    return probabilities.clamp_min(1e-8).log()


@torch.no_grad()
def spatial_diagnostics(logits, padded_size):
    probabilities = logits.detach().softmax(1)
    entropy = -(probabilities * probabilities.clamp_min(1e-8).log()).sum(1, keepdim=True)
    entropy /= math.log(probabilities.shape[1])
    boundary = torch.zeros_like(entropy)
    horizontal = 0.5 * (probabilities[:, :, :, 1:] - probabilities[:, :, :, :-1]).abs().sum(1, keepdim=True)
    vertical = 0.5 * (probabilities[:, :, 1:, :] - probabilities[:, :, :-1, :]).abs().sum(1, keepdim=True)
    boundary[:, :, :, :-1] = torch.maximum(boundary[:, :, :, :-1], horizontal)
    boundary[:, :, :, 1:] = torch.maximum(boundary[:, :, :, 1:], horizontal)
    boundary[:, :, :-1, :] = torch.maximum(boundary[:, :, :-1, :], vertical)
    boundary[:, :, 1:, :] = torch.maximum(boundary[:, :, 1:, :], vertical)
    padding = (0, padded_size[1] - logits.shape[-1], 0, padded_size[0] - logits.shape[-2])
    valid = F.pad(torch.ones_like(entropy), padding)
    entropy = F.avg_pool2d(F.pad(entropy, padding), 16) / F.avg_pool2d(valid, 16).clamp_min(1e-8)
    boundary = F.max_pool2d(F.pad(boundary, padding), 16)
    return entropy.flatten(1), boundary.flatten(1)


class WCSDFormer(DFormer):
    """Actual DFormer with a spatial WCS refinement branch on its query suffix."""

    def __init__(self, cfg, prefix_depth=3, enable_adapter=True, enable_weather=True,
                 enable_state=True, weather_embedding_dim=32, weather_delta=1.0,
                 num_experts=4, top_k=2, **model_settings):
        super().__init__(**DFormer.from_config(cfg))
        self.num_classes = cfg.MODEL.SEM_SEG_HEAD.NUM_CLASSES
        self.width = cfg.MODEL.DFORMER.HIDDEN_DIM
        self.enable_adapter = bool(enable_adapter)
        self.enable_weather = bool(enable_weather)
        self.enable_state = bool(enable_state)
        self.weather_classes = WEATHER_CLASSES
        self.sem_seg_head.predictor = SplitDFormerDecoder(cfg, int(prefix_depth))
        self.prefix_depth = int(prefix_depth)
        suffix_depth = self.sem_seg_head.predictor.num_layers - self.prefix_depth
        self.spatial_adapters = nn.ModuleList([
            SpatialMoE(self.width, num_experts, top_k, weather_delta, enable_weather, enable_state)
            for _ in range(suffix_depth)
        ])
        self.adapter_projection = nn.ModuleList([nn.Linear(self.width, self.width) for _ in range(suffix_depth)])
        for projection in self.adapter_projection:
            nn.init.normal_(projection.weight, std=0.01)
            nn.init.zeros_(projection.bias)
        self.semantic_projection = nn.Conv2d(self.num_classes, self.width, 1)
        self.query_context_projection = nn.Linear(self.width, self.width)
        self.spatial_time_projection = Projection(self.width * 4, self.width)
        if weather_embedding_dim < 4:
            raise ValueError("weather_embedding_dim must be at least 4")
        embeddings = torch.zeros(4, weather_embedding_dim)
        embeddings[:, :4] = torch.eye(4)
        self.register_buffer("weather_embeddings", embeddings)
        self.register_buffer("weather_text_embeddings_is_pretrained_clip", torch.tensor(False))
        self.weather_projection = Projection(weather_embedding_dim, self.width)
        self.weather_classifier = resnet18(weights=None)
        self.weather_classifier.fc = nn.Linear(self.weather_classifier.fc.in_features, 4)
        self.weather_classifier.requires_grad_(False)
        self.weather_classifier.eval()
        half = self.width // 2
        self.risk_inputs = nn.ModuleList([Projection(self.width, half) for _ in range(3)])
        self.risk_head = nn.Sequential(nn.Linear(half * 3, half), nn.GELU(), nn.Linear(half, 1))
        self.gate_inputs = nn.ModuleList([Projection(self.width, half) for _ in range(4)])
        self.gate_head = nn.Sequential(nn.Linear(half * 4 + 1, half), nn.GELU(), nn.Linear(half, 1))

    @property
    def base(self):
        """Compatibility alias: this class itself inherits the real upstream model."""
        return self

    def train(self, mode=True):
        super().train(mode)
        if hasattr(self, "weather_classifier") and not any(p.requires_grad for p in self.weather_classifier.parameters()):
            self.weather_classifier.eval()
        return self

    @torch.no_grad()
    def set_weather_text_embeddings(self, embeddings, is_pretrained_clip=True):
        if embeddings.shape != self.weather_embeddings.shape:
            raise ValueError("Expected weather embeddings of shape %s" % (tuple(self.weather_embeddings.shape),))
        if not torch.isfinite(embeddings).all() or (embeddings.norm(dim=-1) <= 0).any():
            raise ValueError("Weather embeddings must be finite and nonzero")
        self.weather_embeddings.copy_(F.normalize(embeddings.to(self.weather_embeddings), dim=-1))
        self.weather_text_embeddings_is_pretrained_clip.fill_(bool(is_pretrained_clip))

    def encode_condition(self, image, weather_probs=None):
        if image.ndim != 4 or image.shape[1] != 3:
            raise ValueError("Expected RGB images [B,3,H,W] scaled to [0,1]")
        inputs = [{"image": item * 255.0, "height": image.shape[-2], "width": image.shape[-1]} for item in image]
        images, whwh = self.preprocess_image(inputs)
        features = self.backbone(images.tensor)
        mask_features, _, multi_scale = self.sem_seg_head.pixel_decoder.forward_features(features)
        if weather_probs is None:
            mean = image.new_tensor((0.485, 0.456, 0.406))[None, :, None, None]
            std = image.new_tensor((0.229, 0.224, 0.225))[None, :, None, None]
            with torch.no_grad():
                weather_probs = self.weather_classifier((image - mean) / std).softmax(-1)
        else:
            weather_probs = weather_probs.to(image).detach()
            if weather_probs.shape != (image.shape[0], 4) or not torch.isfinite(weather_probs).all() or (weather_probs < 0).any():
                raise ValueError("Expected finite nonnegative weather probabilities [B,4]")
            sums = weather_probs.sum(-1, keepdim=True)
            if (sums <= 0).any():
                raise ValueError("Weather probabilities must have positive sums")
            weather_probs = weather_probs / sums
        weather_probs = weather_probs.detach()
        padded_size = tuple(images.tensor.shape[-2:])
        return {
            "images": images, "images_whwh": whwh, "features": features,
            "mask_features": mask_features, "multi_scale": multi_scale,
            "weather_probs": weather_probs,
            "weather_vector": self.weather_projection(weather_probs @ self.weather_embeddings),
            "image_size": tuple(image.shape[-2:]), "padded_size": padded_size,
            "grid_size": (padded_size[0] // 16, padded_size[1] // 16),
        }

    def prepare_diffusion(self, gt_masks):
        """The unchanged official full-resolution binary-mask corruption path."""
        return self.prepare_diffusion_concat(gt_masks)

    def prepare_prefix(self, noise_masks, timestep, condition):
        if noise_masks.ndim != 4 or noise_masks.shape[1] != self.num_queries:
            raise ValueError("noise_masks must have shape [B,num_queries,H,W] and values in [0,1]")
        decoder = self.sem_seg_head.predictor
        context = decoder.prepare_prefix(condition["multi_scale"], condition["mask_features"], noise_masks, timestep)
        pre_scores = semantic_scores(context["predictions_class"][-1], context["predictions_mask"][-1])
        pre_logits = semantic_logits(pre_scores, condition["padded_size"], condition["image_size"])
        pixel_tokens = F.avg_pool2d(condition["mask_features"], 4, 4).flatten(2).transpose(1, 2)
        probabilities = pre_scores / pre_scores.sum(1, keepdim=True).clamp_min(1e-8)
        semantic_features = self.semantic_projection(F.avg_pool2d(probabilities, 4, 4)).flatten(2).transpose(1, 2)
        masks = context["predictions_mask"][-1].sigmoid()
        queries = context["output"].transpose(0, 1)
        query_map = torch.einsum("bqhw,bqc->bchw", masks, queries) / masks.sum(1, keepdim=True).clamp_min(1e-8)
        query_tokens = F.avg_pool2d(query_map, 4, 4).flatten(2).transpose(1, 2)
        tokens = pixel_tokens + semantic_features + self.query_context_projection(query_tokens)
        time = self.spatial_time_projection(context["time"])
        count = tokens.shape[1]
        time_tokens = time[:, None].expand(-1, count, -1)
        weather_tokens = condition["weather_vector"][:, None].expand(-1, count, -1)
        risk_values = (tokens, pixel_tokens, time_tokens)
        risk = self.risk_head(torch.cat([
            projection(value) for projection, value in zip(self.risk_inputs, risk_values)
        ], dim=-1)).squeeze(-1).sigmoid()
        entropy = -(condition["weather_probs"] * condition["weather_probs"].clamp_min(1e-8).log()).sum(-1, keepdim=True) / math.log(4)
        gate_values = risk_values + (weather_tokens,)
        gate_features = torch.cat([
            projection(value) for projection, value in zip(self.gate_inputs, gate_values)
        ] + [entropy[:, None].expand(-1, count, -1)], dim=-1)
        gate = self.gate_head(gate_features).squeeze(-1).sigmoid()
        uncertainty, boundary = spatial_diagnostics(pre_logits, condition["padded_size"])
        state = torch.stack((uncertainty, boundary, risk.detach()), -1).detach()
        return {
            "decoder_prefix": context, "condition": condition, "tokens": tokens,
            "image_tokens": pixel_tokens, "time": time, "pre_logits": pre_logits,
            "risk": risk, "gate": gate, "state": state, "grid_size": condition["grid_size"],
        }

    def decode_suffix(self, prefix, weather_gate_override=None):
        decoder = self.sem_seg_head.predictor
        context = decoder.copy_context(prefix["decoder_prefix"])
        condition = prefix["condition"]
        tokens = prefix["tokens"]
        initial_tokens = tokens
        gate = prefix["gate"]
        if weather_gate_override is not None:
            gate = torch.full_like(gate, float(weather_gate_override)) if not torch.is_tensor(weather_gate_override) else torch.broadcast_to(weather_gate_override.to(gate), gate.shape)
        routing = []
        for adapter_index, layer in enumerate(range(self.prefix_depth, decoder.num_layers)):
            mask_features = condition["mask_features"]
            memory_residual = None
            if self.enable_adapter:
                tokens, assignments = self.spatial_adapters[adapter_index](
                    tokens, prefix["image_tokens"], prefix["time"],
                    condition["weather_vector"], gate, prefix["state"],
                )
                routing.append(assignments)
                spatial_residual = self.adapter_projection[adapter_index](tokens - initial_tokens)
                spatial_residual = spatial_residual.transpose(1, 2).reshape(
                    tokens.shape[0], self.width, *prefix["grid_size"]
                )
                memory_residual = F.interpolate(spatial_residual, mask_features.shape[-2:], mode="bilinear", align_corners=False)
                mask_features = mask_features + memory_residual
            decoder.run_layer(context, layer, mask_features, memory_residual)
        output = decoder.pack_predictions(context)
        scores = semantic_scores(output["pred_logits"], output["pred_masks"])
        logits = semantic_logits(scores, condition["padded_size"], condition["image_size"])
        output.update({
            "logits": logits, "pre_logits": prefix["pre_logits"], "risk": prefix["risk"],
            "gate": prefix["gate"], "state": prefix["state"], "grid_size": prefix["grid_size"],
            "routing": routing, "condition": condition,
        })
        return output

    @torch.no_grad()
    def sample(self, image, steps=None, seed=0, eta=0.0, weather_probs=None):
        """Official query-mask DDIM update, with explicit optional eta=0 change."""
        was_training = self.training
        self.eval()
        try:
            return self._sample_impl(image, steps, seed, eta, weather_probs)
        finally:
            self.train(was_training)

    def _sample_impl(self, image, steps, seed, eta, weather_probs):
        steps = int(steps if steps is not None else self.sampling_timesteps)
        if not 1 <= steps <= self.num_timesteps or not 0 <= eta <= 1:
            raise ValueError("steps must be in [1,1000] and eta in [0,1]")
        generator = torch.Generator(device=image.device).manual_seed(int(seed))
        condition = self.encode_condition(image, weather_probs)
        state = torch.randn((image.shape[0], self.num_queries, *condition["image_size"]), device=image.device, generator=generator)
        times = list(reversed(torch.linspace(-1, self.num_timesteps - 1, steps=steps + 1).int().tolist()))
        trace = []
        for time, next_time in zip(times[:-1], times[1:]):
            timestep = torch.full((image.shape[0],), time, device=image.device, dtype=torch.long)
            normalized = ((state.clamp(-self.scale, self.scale) / self.scale) + 1) / 2
            prefix = self.prepare_prefix(normalized.float(), timestep, condition)
            output = self.decode_suffix(prefix)
            clean = F.interpolate(output["pred_masks"].sigmoid(), state.shape[-2:], mode="bilinear", align_corners=False)
            clean = ((clean * 2 - 1) * self.scale).clamp(-self.scale, self.scale)
            implied_noise = self.predict_noise_from_start(state, timestep, clean)
            trace.append({"timestep": time, "next_timestep": next_time,
                          "gate_mean": float(output["gate"].mean()), "risk_mean": float(output["risk"].mean())})
            if next_time < 0:
                state = clean
                continue
            alpha = self.alphas_cumprod[time]
            next_alpha = self.alphas_cumprod[next_time]
            sigma = eta * ((1 - alpha / next_alpha) * (1 - next_alpha) / (1 - alpha)).sqrt()
            coefficient = (1 - next_alpha - sigma.square()).clamp_min(0).sqrt()
            noise = torch.randn(clean.shape, device=clean.device, dtype=clean.dtype, generator=generator)
            state = clean * next_alpha.sqrt() + coefficient * implied_noise + sigma * noise
        output["diffusion_trace"] = trace
        output["diffusion_timesteps"] = [entry["timestep"] for entry in trace]
        output["diffusion_state"] = state
        return output

    def forward(self, batched_inputs):
        """Retain the Detectron2 list-of-dicts model interface for train/inference."""
        image = torch.stack([entry["image"].to(self.device).float() / 255.0 for entry in batched_inputs])
        if self.training:
            condition = self.encode_condition(image)
            targets, noise_masks, _, timestep = self.prepare_targets(
                [entry["instances"].to(self.device) for entry in batched_inputs], condition["images"]
            )
            for target, entry in zip(targets, batched_inputs):
                if "sem_seg" in entry:
                    semantic = entry["sem_seg"].to(self.device)
                    valid = (semantic >= 0) & (semantic < self.num_classes)
                else:
                    valid = torch.ones(entry["image"].shape[-2:], device=self.device, dtype=torch.bool)
                padded_valid = torch.zeros(target["masks"].shape[-2:], device=self.device, dtype=torch.bool)
                height = min(valid.shape[-2], padded_valid.shape[-2])
                width = min(valid.shape[-1], padded_valid.shape[-1])
                padded_valid[:height, :width] = valid[:height, :width]
                target["valid"] = padded_valid
            prefix = self.prepare_prefix(noise_masks, timestep.squeeze(-1), condition)
            output = self.decode_suffix(prefix)
            predictions = {key: output[key] for key in ("pred_logits", "pred_masks", "aux_outputs")}
            losses = self.criterion(predictions, targets)
            return {key: value * self.criterion.weight_dict[key] for key, value in losses.items() if key in self.criterion.weight_dict}
        output = self.sample(image, eta=0.0)
        results = []
        for index, entry in enumerate(batched_inputs):
            height = entry.get("height", image.shape[-2])
            width = entry.get("width", image.shape[-1])
            scores = F.interpolate(output["logits"][index:index + 1].exp(), (height, width), mode="bilinear", align_corners=False)[0]
            results.append({"sem_seg": scores, "wcs": {
                "gate": output["gate"][index], "risk": output["risk"][index], "state": output["state"][index],
                "grid_size": output["grid_size"],
            }})
        return results
