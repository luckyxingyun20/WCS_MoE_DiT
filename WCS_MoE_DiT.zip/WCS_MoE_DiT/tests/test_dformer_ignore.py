"""Check that ACDC ignore pixels cannot supervise DFormer's mask objectives."""

import unittest

import torch

from dformer_ext.losses import build_criterion, semantic_targets, wcs_losses


class DFormerIgnoreContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def setUp(self):
        torch.manual_seed(4)
        self.labels = torch.full((1, 16, 16), 255, dtype=torch.long)
        self.labels[:, :8, :8] = 0
        self.labels[:, 8:, 8:] = 1
        self.targets = semantic_targets(self.labels)
        self.criterion = build_criterion(decoder_layers=2, num_points=64)

    @staticmethod
    def predictions(batch=1, size=16, auxiliary=True, device="cpu"):
        output = {
            "pred_logits": torch.randn(batch, 4, 20, device=device, requires_grad=True),
            "pred_masks": torch.randn(batch, 4, size, size, device=device, requires_grad=True),
        }
        if auxiliary:
            output["aux_outputs"] = [{
                "pred_logits": torch.randn(batch, 4, 20, device=device, requires_grad=True),
                "pred_masks": torch.randn(batch, 4, size, size, device=device, requires_grad=True),
            }]
        return output

    def test_target_format_and_official_weights(self):
        target = self.targets[0]
        self.assertEqual(target["labels"].tolist(), [0, 1])
        self.assertEqual(tuple(target["masks"].shape), (2, 16, 16))
        self.assertEqual(int(target["valid"].sum()), 128)
        self.assertEqual(int(target["masks"][:, ~target["valid"]].count_nonzero()), 0)
        self.assertEqual(self.criterion.weight_dict, {
            "loss_ce": 2.0, "loss_mask": 5.0, "loss_dice": 5.0,
            "loss_ce_0": 2.0, "loss_mask_0": 5.0, "loss_dice_0": 5.0,
        })

    def test_hungarian_and_main_aux_losses_ignore_invalid_predictions(self):
        original = self.predictions()
        invalid = ~self.targets[0]["valid"]
        changed_masks = original["pred_masks"].detach().clone()
        changed_masks[0, :, invalid] = 1000.0
        changed_aux = original["aux_outputs"][0]["pred_masks"].detach().clone()
        changed_aux[0, :, invalid] = -1000.0
        changed = {
            "pred_logits": original["pred_logits"],
            "pred_masks": changed_masks,
            "aux_outputs": [{"pred_logits": original["aux_outputs"][0]["pred_logits"],
                             "pred_masks": changed_aux}],
        }
        torch.manual_seed(20)
        first_match = self.criterion.matcher(original, self.targets)
        torch.manual_seed(20)
        second_match = self.criterion.matcher(changed, self.targets)
        for first, second in zip(first_match[0], second_match[0]):
            torch.testing.assert_close(first, second, rtol=0, atol=0)
        # Replay identical valid point draws, changing only ignored predictions.
        torch.manual_seed(30)
        first_losses = self.criterion(original, self.targets)
        torch.manual_seed(30)
        second_losses = self.criterion(changed, self.targets)
        self.assertEqual(set(first_losses), set(self.criterion.weight_dict))
        for key in first_losses:
            torch.testing.assert_close(first_losses[key], second_losses[key], rtol=0, atol=0)
        weighted_loss = sum(value * self.criterion.weight_dict[key]
                            for key, value in first_losses.items())
        weighted_loss.backward()
        for masks in (original["pred_masks"], original["aux_outputs"][0]["pred_masks"]):
            self.assertIsNotNone(masks.grad)
            self.assertEqual(int(masks.grad[0, :, invalid].count_nonzero()), 0)
            self.assertGreater(float(masks.grad[0, :, ~invalid].abs().sum()), 0.0)

    def test_all_ignored_has_finite_class_loss_and_zero_mask_backward(self):
        ignored = torch.full((2, 16, 16), 255, dtype=torch.long)
        targets = semantic_targets(ignored)
        self.assertTrue(all(target["labels"].numel() == 0 for target in targets))
        output = self.predictions(batch=2, size=4)
        losses = self.criterion(output, targets)
        self.assertTrue(all(bool(torch.isfinite(value)) for value in losses.values()))
        for key in ("loss_mask", "loss_dice", "loss_mask_0", "loss_dice_0"):
            self.assertEqual(float(losses[key]), 0.0)
            self.assertTrue(losses[key].requires_grad)
        # Preserve the official no-object classification treatment of empty sets.
        self.assertGreater(float(losses["loss_ce"]), 0.0)
        sum(losses.values()).backward()
        for masks in (output["pred_masks"], output["aux_outputs"][0]["pred_masks"]):
            self.assertIsNotNone(masks.grad)
            self.assertEqual(int(masks.grad.count_nonzero()), 0)
        self.assertIsNotNone(output["pred_logits"].grad)

    def test_low_resolution_masks_sample_valid_centers_and_backpropagate(self):
        output = self.predictions(size=4, auxiliary=False)
        losses = self.criterion(output, self.targets)
        self.assertTrue(all(bool(torch.isfinite(value)) for value in losses.values()))
        sum(losses.values()).backward()
        self.assertIsNotNone(output["pred_masks"].grad)
        self.assertTrue(bool(torch.isfinite(output["pred_masks"].grad).all()))
        self.assertGreater(float(output["pred_masks"].grad.abs().sum()), 0.0)

    def test_original_dformer_without_adapter_has_zero_wcs_loss(self):
        output = self.predictions(auxiliary=False)
        losses = wcs_losses(output, self.labels, torch.ones(1), spatial_moe_enabled=False)
        self.assertEqual(set(losses), {"pre", "err", "util", "str", "bal", "total_wcs"})
        self.assertTrue(all(float(value) == 0.0 for value in losses.values()))
        losses["total_wcs"].backward()
        self.assertIsNotNone(output["pred_masks"].grad)
        self.assertEqual(int(output["pred_masks"].grad.count_nonzero()), 0)

    @unittest.skipUnless(torch.cuda.is_available(), "CUDA is unavailable in this process")
    def test_valid_point_indices_follow_cuda_prediction_device(self):
        criterion = build_criterion(decoder_layers=1, num_points=64).to("cuda")
        targets = semantic_targets(self.labels.to("cuda"))
        output = self.predictions(size=4, auxiliary=False, device="cuda")
        losses = criterion(output, targets)
        self.assertTrue(all(bool(torch.isfinite(value)) for value in losses.values()))
        sum(losses.values()).backward()
        self.assertGreater(float(output["pred_masks"].grad.abs().sum()), 0.0)


if __name__ == "__main__":
    unittest.main()
