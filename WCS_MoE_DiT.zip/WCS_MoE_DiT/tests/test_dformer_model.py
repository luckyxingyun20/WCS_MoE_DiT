"""Contracts proving the upgrade executes the actual published DFormer core."""

import tempfile
import unittest
from pathlib import Path

import torch

from dformer_ext.bootstrap import build_dformer_cfg
from dformer_ext.model import WCSDFormer, MultiScaleMaskedTransformerDecoder
from dformer_ext.losses import build_criterion
from detectron2.structures import Instances


class DFormerModelContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        torch.manual_seed(19)
        cls.settings = {"model": {
            "width": 256, "prefix_depth": 3, "suffix_depth": 6,
            "pixel_encoder_layers": 6, "num_queries": 100,
            "num_heads": 8, "num_points": 64, "num_classes": 19,
        }}
        cls.cfg = build_dformer_cfg(cls.settings, "cpu")
        cls.model = WCSDFormer(cls.cfg)
        cls.image = torch.rand(1, 3, 64, 64)
        cls.noise = torch.rand(1, 100, 64, 64)
        cls.time = torch.tensor([500])

    def setUp(self):
        self.model.eval()
        self.model.enable_adapter = True
        self.model.zero_grad(set_to_none=True)

    def test_disabled_adapter_exact_official_parity_and_noise_influence(self):
        self.model.enable_adapter = False
        with torch.no_grad():
            condition = self.model.encode_condition(self.image)
            original = MultiScaleMaskedTransformerDecoder.forward(
                self.model.sem_seg_head.predictor, condition["multi_scale"],
                condition["mask_features"], self.noise, self.time,
            )
            prefix = self.model.prepare_prefix(self.noise, self.time, condition)
            actual = self.model.decode_suffix(prefix)
            for key in ("pred_logits", "pred_masks"):
                self.assertTrue(torch.equal(original[key], actual[key]), key)
            self.assertEqual(len(actual["aux_outputs"]), 8)
            for expected_aux, actual_aux in zip(original["aux_outputs"], actual["aux_outputs"]):
                for key in ("pred_logits", "pred_masks"):
                    self.assertTrue(torch.equal(expected_aux[key], actual_aux[key]), key)
            different = self.model.decode_suffix(self.model.prepare_prefix(1.0 - self.noise, self.time, condition))
            self.assertGreater(float((actual["pred_masks"] - different["pred_masks"]).abs().max()), 1e-7)

    def test_six_sparse_spatial_layers_and_matched_candidates(self):
        counts = [0] * 6
        handles = []
        for layer_id, adapter in enumerate(self.model.spatial_adapters):
            for expert in adapter.experts:
                def count_tokens(module, arguments, layer_id=layer_id):
                    counts[layer_id] += arguments[0].shape[0]
                handles.append(expert.register_forward_pre_hook(count_tokens))
        try:
            with torch.no_grad():
                condition = self.model.encode_condition(self.image)
                prefix = self.model.prepare_prefix(self.noise, self.time, condition)
                actual = self.model.decode_suffix(prefix)
        finally:
            for handle in handles:
                handle.remove()
        self.assertEqual(counts, [1 * 4 * 4 * 2] * 6)
        self.assertEqual(len(actual["routing"]), 6)
        for layer in actual["routing"]:
            self.assertEqual(tuple(layer["probs"].shape), (1, 16, 4))
            self.assertEqual(tuple(layer["indices"].shape), (1, 16, 2))
            self.assertTrue(torch.allclose(layer["weights"].sum(-1), torch.ones(1, 16)))
        with torch.no_grad():
            on = self.model.decode_suffix(prefix, 1.0)
            repeated = self.model.decode_suffix(prefix, 1.0)
            off = self.model.decode_suffix(prefix, 0.0)
        self.assertTrue(torch.equal(on["pred_masks"], repeated["pred_masks"]))
        self.assertGreater(float((on["logits"] - off["logits"]).abs().max()), 1e-7)
        self.assertFalse(actual["state"].requires_grad)

    def test_cached_rgb_deterministic_ddim_and_mode_restore(self):
        calls = []
        handle = self.model.backbone.register_forward_pre_hook(lambda module, arguments: calls.append(1))
        try:
            first = self.model.sample(self.image, steps=2, seed=77, eta=0)
            self.assertEqual(len(calls), 1)
            second = self.model.sample(self.image, steps=2, seed=77, eta=0)
            self.assertEqual(len(calls), 2)
        finally:
            handle.remove()
        self.assertTrue(torch.equal(first["pred_masks"], second["pred_masks"]))
        self.assertEqual(first["diffusion_timesteps"], [999, 499])
        self.model.train()
        with self.assertRaises(ValueError):
            self.model.sample(self.image, steps=0)
        self.assertTrue(self.model.training)
        self.assertFalse(self.model.weather_classifier.training)

    def test_strict_checkpoint_reload(self):
        with torch.no_grad():
            condition = self.model.encode_condition(self.image)
            expected = self.model.decode_suffix(self.model.prepare_prefix(self.noise, self.time, condition))["pred_masks"]
        with tempfile.TemporaryDirectory(prefix="wcs_dformer_checkpoint_") as directory:
            checkpoint = Path(directory) / "state.pt"
            torch.save(self.model.state_dict(), checkpoint)
            restored = WCSDFormer(self.cfg).eval()
            status = restored.load_state_dict(torch.load(str(checkpoint), map_location="cpu"), strict=True)
            self.assertEqual(status.missing_keys, [])
            self.assertEqual(status.unexpected_keys, [])
            with torch.no_grad():
                condition = restored.encode_condition(self.image)
                actual = restored.decode_suffix(restored.prepare_prefix(self.noise, self.time, condition))["pred_masks"]
            self.assertTrue(torch.equal(expected, actual))

    def test_detectron_training_interface_validity_and_finite_backward(self):
        old_criterion = self.model.criterion
        self.model.criterion = build_criterion(num_classes=19, decoder_layers=10, num_points=64)
        self.model.train()
        label = torch.zeros(64, 64, dtype=torch.long)
        label[:, 32:] = 1
        label[20:24, :] = 255
        instances = Instances((64, 64))
        instances.gt_classes = torch.tensor([0, 1])
        instances.gt_masks = torch.stack((label == 0, label == 1))
        try:
            losses = self.model([{"image": self.image[0] * 255, "instances": instances, "sem_seg": label}])
            self.assertEqual(len(losses), 27)
            total = sum(losses.values())
            self.assertTrue(torch.isfinite(total))
            total.backward()
            for parameter in self.model.parameters():
                if parameter.grad is not None:
                    self.assertTrue(torch.isfinite(parameter.grad).all())
            self.assertGreater(float(self.model.spatial_adapters[0].weather_router.weight.grad.abs().sum()), 0)
            self.assertFalse(self.model.weather_classifier.training)
        finally:
            self.model.criterion = old_criterion
            self.model.zero_grad(set_to_none=True)


if __name__ == "__main__":
    unittest.main()
