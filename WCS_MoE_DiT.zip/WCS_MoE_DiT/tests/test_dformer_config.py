"""A checkpoint's corruption scale and architecture must survive inference overrides."""
import copy
import unittest

from dformer_demo import restore_inference_config


class CheckpointConfiguration(unittest.TestCase):
    def test_restore_trained_scale_and_architecture_but_allow_sampling_choices(self):
        saved = {'device': 'cuda', 'output_dir': 'outputs/train', 'data': {'image_size': 128},
                 'model': {'width': 256, 'num_queries': 100},
                 'extension': {'enable_adapter': False, 'weather_embedding_dim': 512},
                 'diffusion': {'training_steps': 1000, 'snr_scale': 0.5, 'inference_steps': 4, 'eta': 1},
                 'weather': {'embeddings_file': '/old/machine/clip.pt'}}
        requested = copy.deepcopy(saved)
        requested.update(device='cpu', output_dir='outputs/infer')
        requested['diffusion'].update(snr_scale=0.1, inference_steps=2, eta=0)
        requested['extension']['enable_adapter'] = True
        restored = restore_inference_config(saved, requested)
        self.assertEqual(restored['diffusion']['snr_scale'], 0.5)
        self.assertEqual(restored['diffusion']['inference_steps'], 2)
        self.assertEqual(restored['diffusion']['eta'], 0)
        self.assertFalse(restored['extension']['enable_adapter'])
        self.assertEqual(restored['extension']['weather_embedding_dim'], 512)
        self.assertIsNone(restored['weather']['embeddings_file'])
        self.assertEqual(restored['device'], 'cpu')
        self.assertEqual(saved['diffusion']['inference_steps'], 4)
        self.assertEqual(saved['weather']['embeddings_file'], '/old/machine/clip.pt')
