"""Verify supervision boundaries and diffusion/routing contracts on CPU."""
import unittest
from unittest.mock import patch

import torch

from wcs_moe_dit.diffusion import CosineDiffusion
from wcs_moe_dit.losses import (clean_mask_target, compute_losses, structure_loss,
                               structure_eligibility, utility_target)
from wcs_moe_dit.model import WCSMoEDiT


class MechanismContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        torch.manual_seed(7)
        cls.model = WCSMoEDiT(width=32)
        cls.diffusion = CosineDiffusion(training_steps=20)

    def test_valid_occupancy_and_all_ignored_losses(self):
        labels = torch.full((1, 32, 32), 255, dtype=torch.long)
        labels[0, :4, :2] = 0
        labels[0, :4, 2:4] = 1
        clean, valid = clean_mask_target(labels)
        self.assertEqual(int(valid.sum()), 1)
        self.assertEqual(float(clean[0, 0, 0, 0]), 0.0)
        self.assertEqual(float(clean[0, 1, 0, 0]), 0.0)
        self.assertEqual(float(clean[0, 2, 0, 0]), -1.0)
        self.assertEqual(float(clean[0, :, 1:, :].abs().sum()), 0.0)
        ignored = torch.full((1, 64, 64), 255, dtype=torch.long)
        target, valid_low = clean_mask_target(ignored)
        self.model.train()
        output = self.model(torch.rand(1, 3, 64, 64), torch.randn_like(target), torch.tensor([10]))
        losses = compute_losses(output, ignored, target, valid_low, torch.tensor([0.5]))
        for key in ('seg', 'rec', 'pre', 'err', 'util', 'str'):
            self.assertEqual(float(losses[key]), 0.0)
        self.assertTrue(all(torch.isfinite(value) for value in losses.values()))
        self.model.zero_grad(set_to_none=True)
        losses['total'].backward()

    def test_common_prediction_losses_in_baseline(self):
        labels = torch.zeros(1, 64, 64, dtype=torch.long)
        target, valid = clean_mask_target(labels)
        output = self.model(torch.rand(1, 3, 64, 64), target, torch.tensor([10]))
        losses = compute_losses(output, labels, target, valid, torch.tensor([0.5]),
                                enable_state=False, enable_weather=False)
        self.assertGreater(float(losses['pre']), 0.0)
        self.assertGreater(float(losses['err']), 0.0)
        self.assertEqual(float(losses['str']), 0.0)
        self.assertEqual(float(losses['util']), 0.0)

    def test_utility_sign_and_detachment(self):
        labels = torch.zeros(1, 32, 32, dtype=torch.long)
        on = torch.zeros(1, 19, 32, 32, requires_grad=True)
        off = torch.zeros_like(on, requires_grad=True)
        with torch.no_grad():
            on[:, 0] = 5
        target, valid = utility_target(on, off, labels, (2, 2))
        self.assertTrue(bool((target > 0.5).all()))
        self.assertFalse(target.requires_grad)
        self.assertTrue(bool(valid.all()))
        reversed_target, _ = utility_target(off, on, labels, (2, 2))
        self.assertTrue(bool((reversed_target < 0.5).all()))

    def test_structure_uses_interiors_and_excludes_boundaries(self):
        probs = torch.tensor([[[0.8, 0.1, 0.05, 0.05], [0.1, 0.8, 0.05, 0.05],
                               [0.8, 0.1, 0.05, 0.05], [0.1, 0.8, 0.05, 0.05]]], requires_grad=True)
        routes = [{'probs': probs}]
        labels = torch.zeros(1, 32, 32, dtype=torch.long)
        risk = torch.zeros(1, 4, requires_grad=True)
        interior_loss = structure_loss(routes, labels, risk, (2, 2), torch.tensor([1.0]))
        self.assertGreater(float(interior_loss), 0.01)
        interior_loss.backward()
        self.assertIsNone(risk.grad)
        self.assertIsNotNone(probs.grad)
        labels[:, :, 16:] = 1
        self.assertEqual(int(structure_eligibility(labels, (2, 2))['eligible_pairs'].sum()), 0)
        self.assertEqual(float(structure_loss(routes, labels, risk, (2, 2), torch.tensor([1.0]))), 0.0)

    def test_top2_dispatch_detached_state_and_classifier_freeze(self):
        self.model.train()
        self.assertFalse(self.model.weather_classifier.training)
        batch, size = 2, 64
        condition = self.model.encode_condition(torch.rand(batch, 3, size, size),
                                                 weather_probs=torch.full((batch, 4), 0.25))
        prefix = self.model.prepare_prefix(torch.randn(batch, 19, size // 4, size // 4),
                                           torch.tensor([4, 10]), condition)
        self.assertFalse(prefix['state'].requires_grad)
        dispatched = []
        handles = [expert.register_forward_pre_hook(lambda module, inputs: dispatched.append(inputs[0].shape[0]))
                   for expert in self.model.suffix_blocks[0].moe.experts]
        try:
            output = self.model.decode_suffix(prefix)
        finally:
            for handle in handles:
                handle.remove()
        route = output['routing'][0]
        self.assertEqual(sum(dispatched), batch * (size // 16) ** 2 * 2)
        self.assertTrue(bool((route['indices'][..., 0] != route['indices'][..., 1]).all()))
        torch.testing.assert_close(route['weights'].sum(-1), torch.ones_like(prefix['risk']))
        self.assertTrue(bool(((prefix['gate'] >= 0) & (prefix['gate'] <= 1)).all()))

    def test_ddim_schedule_exact_clean_end_and_rgb_only_replay(self):
        self.assertEqual(float(self.diffusion.alpha_bar[0]), 1.0)
        self.assertAlmostEqual(float(self.diffusion.alpha_bar[-1]), 1e-5, places=9)
        clean = torch.randn(1, 19, 8, 8)
        noisy = self.diffusion.q_sample(clean, 20)
        torch.testing.assert_close(self.diffusion.step(noisy, clean, 20, 0), clean)
        image = torch.rand(1, 3, 65, 97)
        with patch.object(self.model, 'encode_condition', wraps=self.model.encode_condition) as encode:
            first = self.diffusion.sample(self.model, image, steps=3, seed=123)
            self.assertEqual(encode.call_count, 1)
        second = self.diffusion.sample(self.model, image, steps=3, seed=123)
        self.assertEqual(first['logits'].shape, (1, 19, 65, 97))
        self.assertEqual(len(first['diffusion_timesteps']), 3)
        torch.testing.assert_close(first['logits'], second['logits'], rtol=0, atol=0)


if __name__ == '__main__':
    unittest.main()
