"""Cosine mask corruption and deterministic DDIM sampling."""

import math
from typing import Optional

import torch
from torch import nn


class CosineDiffusion(nn.Module):
    def __init__(self, training_steps: int = 1000, offset: float = 0.008,
                 min_signal: float = 1e-5):
        super().__init__()
        if training_steps < 1 or not 0 < min_signal < 1 or offset < 0:
            raise ValueError("Invalid diffusion schedule configuration")
        self.training_steps = int(training_steps)
        times = torch.arange(self.training_steps + 1, dtype=torch.float64) / self.training_steps
        signal = torch.cos((times + offset) / (1 + offset) * math.pi / 2).square()
        signal = (signal / signal[0]).clamp_min(min_signal)
        signal[0] = 1.0
        self.register_buffer("alpha_bar", signal.float())

    def _times(self, timestep, reference: torch.Tensor) -> torch.Tensor:
        values = torch.as_tensor(timestep, device=reference.device)
        if values.is_floating_point() and not torch.equal(values, values.round()):
            raise ValueError("Diffusion timesteps must be integers")
        values = values.long()
        if values.ndim == 0:
            values = values.expand(reference.shape[0])
        if values.ndim != 1 or values.shape[0] != reference.shape[0]:
            raise ValueError("Timesteps must be scalar or one value per image")
        if (values < 0).any() or (values > self.training_steps).any():
            raise ValueError("Diffusion timestep outside schedule")
        return values

    def _alpha(self, timestep, reference: torch.Tensor) -> torch.Tensor:
        times = self._times(timestep, reference)
        coefficients = self.alpha_bar.to(device=reference.device, dtype=reference.dtype)[times]
        return coefficients.reshape(reference.shape[0], *([1] * (reference.ndim - 1)))

    def q_sample(self, clean: torch.Tensor, timestep, noise: Optional[torch.Tensor] = None):
        times = self._times(timestep, clean)
        if (times == 0).any():
            raise ValueError("Training corruption uses timesteps 1 through T")
        if noise is None:
            noise = torch.randn_like(clean)
        if noise.shape != clean.shape:
            raise ValueError("Noise and clean mask must have matching shapes")
        alpha = self._alpha(times, clean)
        return alpha.sqrt() * clean + (1 - alpha).sqrt() * noise

    def step(self, noisy: torch.Tensor, clean: torch.Tensor, timestep, next_timestep):
        """An eta=0 DDIM update, evaluated only for a positive current time."""
        if noisy.shape != clean.shape:
            raise ValueError("Noisy and clean masks must have matching shapes")
        times = self._times(timestep, noisy)
        next_times = self._times(next_timestep, noisy)
        if (times <= 0).any() or (next_times >= times).any():
            raise ValueError("DDIM requires 0 <= next_timestep < timestep")
        alpha = self._alpha(times, noisy)
        next_alpha = self._alpha(next_times, noisy)
        implied_noise = (noisy - alpha.sqrt() * clean) / (1 - alpha).sqrt().clamp_min(1e-12)
        return next_alpha.sqrt() * clean + (1 - next_alpha).sqrt() * implied_noise

    @torch.no_grad()
    def sample(self, model, image: torch.Tensor, steps: int = 4, seed: int = 0,
               weather_probs: Optional[torch.Tensor] = None):
        """Segment RGB images with cached image/weather conditions and no labels."""
        if steps < 1 or steps > self.training_steps:
            raise ValueError("Sampling steps must be between 1 and training_steps")
        if image.ndim != 4 or image.shape[1] != 3:
            raise ValueError("Input image must have shape [B,3,H,W]")
        was_training = model.training
        model.eval()
        try:
            condition = model.encode_condition(image, weather_probs=weather_probs)
            height, width = image.shape[-2:]
            low_height, low_width = math.ceil(height / 4), math.ceil(width / 4)
            if isinstance(condition, dict) and "low_size" in condition:
                low_height, low_width = condition["low_size"]
            num_classes = int(getattr(model, "num_classes", 19))
            generator = torch.Generator(device=image.device).manual_seed(int(seed))
            noisy = torch.randn((image.shape[0], num_classes, low_height, low_width),
                                device=image.device, dtype=image.dtype, generator=generator)
            timesteps = torch.linspace(self.training_steps, 1, int(steps)).round().long().tolist()
            final_output = None
            for index, timestep in enumerate(timesteps):
                times = torch.full((image.shape[0],), timestep, device=image.device, dtype=torch.long)
                prefix = model.prepare_prefix(noisy, times, condition)
                suffix = model.decode_suffix(prefix)
                final_output = dict(prefix)
                final_output.update(suffix)
                next_timestep = timesteps[index + 1] if index + 1 < len(timesteps) else 0
                noisy = self.step(noisy, final_output["clean"], times, next_timestep)
            final_output["diffusion_timesteps"] = timesteps
            return final_output
        finally:
            model.train(was_training)
