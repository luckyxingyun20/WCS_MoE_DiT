"""Losses for the WCS-MoE-DiT demo.

Ground-truth labels are used only here.  All token targets exclude Cityscapes
ignore labels, and empty crops return a differentiable zero loss.
"""

from typing import Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn.functional as F


NUM_CLASSES = 19


def _valid_labels(labels: torch.Tensor, num_classes: int = NUM_CLASSES) -> torch.Tensor:
    return (labels >= 0) & (labels < num_classes)


def _grid(grid_size: Sequence[int]) -> Tuple[int, int]:
    height, width = int(grid_size[0]), int(grid_size[1])
    if height < 1 or width < 1:
        raise ValueError("Token grid dimensions must be positive")
    return height, width


def _masked_mean(values: torch.Tensor, valid: torch.Tensor) -> torch.Tensor:
    weights = valid.to(values.dtype)
    return (values * weights).sum() / weights.sum().clamp_min(1.0)


def _token_pool(values: torch.Tensor, grid_size: Sequence[int], maximum: bool = False):
    """Pool true 16px footprints, with zero contribution from image padding."""
    height, width = _grid(grid_size)
    pad_height = height * 16 - values.shape[-2]
    pad_width = width * 16 - values.shape[-1]
    if pad_height < 0 or pad_width < 0:
        raise ValueError("Token grid must cover the image using 16px footprints")
    padded = F.pad(values, (0, pad_width, 0, pad_height))
    if maximum:
        return F.max_pool2d(padded, 16, stride=16)
    return F.avg_pool2d(padded, 16, stride=16)


def clean_mask_target(labels: torch.Tensor, num_classes: int = NUM_CLASSES):
    """Pool valid one-hot labels to quarter resolution and map them to [-1, 1]."""
    if labels.ndim != 3 or min(labels.shape[-2:]) < 4:
        raise ValueError("Labels must have shape [B,H,W] with H,W >= 4")
    valid = _valid_labels(labels, num_classes)
    safe_labels = labels.long().clamp(0, num_classes - 1)
    one_hot = F.one_hot(safe_labels, num_classes).permute(0, 3, 1, 2).float()
    one_hot = one_hot * valid.unsqueeze(1)
    size = (labels.shape[-2] // 4, labels.shape[-1] // 4)
    valid_fraction = F.adaptive_avg_pool2d(valid.unsqueeze(1).float(), size)
    proportions = F.adaptive_avg_pool2d(one_hot, size) / valid_fraction.clamp_min(1e-12)
    valid_low = valid_fraction > 0
    clean = (2.0 * proportions - 1.0) * valid_low.to(proportions.dtype)
    return clean, valid_low


def _pixel_cross_entropy(logits: torch.Tensor, labels: torch.Tensor):
    valid = _valid_labels(labels, logits.shape[1])
    safe_labels = torch.where(valid, labels.long(), torch.full_like(labels.long(), 255))
    losses = F.cross_entropy(logits.float(), safe_labels, ignore_index=255, reduction="none")
    return losses, valid


def masked_cross_entropy(logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """Cross-entropy with a finite, graph-connected zero for fully ignored crops."""
    losses, valid = _pixel_cross_entropy(logits, labels)
    return _masked_mean(losses, valid)


def token_average(values: torch.Tensor, labels: torch.Tensor, grid_size: Sequence[int]):
    """Average pixel values over valid pixels in each token footprint."""
    if values.shape != labels.shape:
        raise ValueError("Pixel values and labels must both have shape [B,H,W]")
    valid = _valid_labels(labels)
    denominator = _token_pool(valid.unsqueeze(1).float(), grid_size)
    numerator = _token_pool((values.float() * valid).unsqueeze(1), grid_size)
    average = numerator / denominator.clamp_min(1e-12)
    return average.flatten(1), (denominator > 0).flatten(1)


@torch.no_grad()
def risk_target(pre_logits: torch.Tensor, labels: torch.Tensor, grid_size: Sequence[int]):
    errors = (pre_logits.argmax(1) != labels).float()
    return token_average(errors, labels, grid_size)


@torch.no_grad()
def utility_target(
    on_logits: torch.Tensor,
    off_logits: torch.Tensor,
    labels: torch.Tensor,
    grid_size: Sequence[int],
    tau: float = 0.1,
):
    """ON improvements produce targets above 0.5; ignored tokens are masked."""
    if tau <= 0:
        raise ValueError("Utility temperature must be positive")
    on_loss, _ = _pixel_cross_entropy(on_logits, labels)
    off_loss, _ = _pixel_cross_entropy(off_logits, labels)
    difference, valid = token_average(off_loss - on_loss, labels, grid_size)
    return torch.sigmoid(difference / tau), valid


@torch.no_grad()
def structure_eligibility(
    labels: torch.Tensor,
    grid_size: Sequence[int],
    num_classes: int = NUM_CLASSES,
    purity_threshold: float = 0.9,
    boundary_radius: int = 2,
) -> Dict[str, torch.Tensor]:
    """Identify adjacent tokens contained in the same homogeneous interior.

    Boundaries mark both pixels of a valid four-neighbor class change.  The
    exclusion band is dilated by ``boundary_radius`` input-image pixels.
    """
    if boundary_radius < 0:
        raise ValueError("Boundary radius must be nonnegative")
    _grid(grid_size)
    valid = _valid_labels(labels, num_classes)
    safe_labels = labels.long().clamp(0, num_classes - 1)
    one_hot = F.one_hot(safe_labels, num_classes).permute(0, 3, 1, 2).float()
    fractions = _token_pool(one_hot * valid.unsqueeze(1), grid_size)
    valid_fraction = _token_pool(valid.unsqueeze(1).float(), grid_size)
    purity, dominant = (fractions / valid_fraction.clamp_min(1e-12)).max(dim=1)

    boundary = torch.zeros_like(valid)
    horizontal_change = (
        valid[:, :, :-1] & valid[:, :, 1:] & (labels[:, :, :-1] != labels[:, :, 1:])
    )
    vertical_change = (
        valid[:, :-1, :] & valid[:, 1:, :] & (labels[:, :-1, :] != labels[:, 1:, :])
    )
    boundary[:, :, :-1] |= horizontal_change
    boundary[:, :, 1:] |= horizontal_change
    boundary[:, :-1, :] |= vertical_change
    boundary[:, 1:, :] |= vertical_change
    band = boundary.unsqueeze(1).float()
    if boundary_radius:
        band = F.max_pool2d(band, 2 * boundary_radius + 1, stride=1, padding=boundary_radius)
    touches_boundary = _token_pool(band, grid_size, maximum=True).squeeze(1).bool()
    interior = (valid_fraction.squeeze(1) > 0) & (purity > purity_threshold) & ~touches_boundary
    horizontal = (
        interior[:, :, :-1] & interior[:, :, 1:] & (dominant[:, :, :-1] == dominant[:, :, 1:])
    )
    vertical = (
        interior[:, :-1, :] & interior[:, 1:, :] & (dominant[:, :-1, :] == dominant[:, 1:, :])
    )
    return {
        "horizontal": horizontal,
        "vertical": vertical,
        "interior": interior,
        "purity": purity,
        "dominant": dominant,
        "eligible_pairs": horizontal.flatten(1).sum(1) + vertical.flatten(1).sum(1),
    }


def _js_divergence(first: torch.Tensor, second: torch.Tensor) -> torch.Tensor:
    first = first.float().clamp_min(1e-8)
    second = second.float().clamp_min(1e-8)
    midpoint = 0.5 * (first + second)
    return 0.5 * (
        (first * (first.log() - midpoint.log())).sum(-1)
        + (second * (second.log() - midpoint.log())).sum(-1)
    )


def structure_loss(
    routing: List[Dict[str, torch.Tensor]],
    labels: torch.Tensor,
    risk: torch.Tensor,
    grid_size: Sequence[int],
    alpha_bar: torch.Tensor,
    purity_threshold: float = 0.9,
    boundary_radius: int = 2,
) -> torch.Tensor:
    if not routing:
        return risk.sum() * 0.0
    height, width = _grid(grid_size)
    eligibility = structure_eligibility(labels, grid_size, purity_threshold=purity_threshold,
                                        boundary_radius=boundary_radius)
    reliability = (1.0 - risk.detach().float().clamp(0, 1)).reshape(-1, height, width)
    horizontal_weight = (
        eligibility["horizontal"] * reliability[:, :, :-1] * reliability[:, :, 1:]
    )
    vertical_weight = (
        eligibility["vertical"] * reliability[:, :-1, :] * reliability[:, 1:, :]
    )
    weight_sum = horizontal_weight.flatten(1).sum(1) + vertical_weight.flatten(1).sum(1)
    per_layer = []
    for route in routing:
        probs = route["probs"].reshape(labels.shape[0], height, width, -1)
        horizontal_js = _js_divergence(probs[:, :, :-1], probs[:, :, 1:])
        vertical_js = _js_divergence(probs[:, :-1, :], probs[:, 1:, :])
        numerator = (horizontal_js * horizontal_weight).flatten(1).sum(1)
        numerator = numerator + (vertical_js * vertical_weight).flatten(1).sum(1)
        per_layer.append(numerator / (weight_sum + 1e-8))
    per_image = torch.stack(per_layer).mean(0)
    attenuation = torch.as_tensor(alpha_bar, device=per_image.device, dtype=per_image.dtype)
    return (per_image * attenuation.reshape(-1)).mean()


def load_balance_loss(routing: List[Dict[str, torch.Tensor]]) -> torch.Tensor:
    """Normalize selection counts by all Top-K assignments, as in the paper."""
    if not routing:
        return torch.tensor(0.0)
    losses = []
    for route in routing:
        probs = route["probs"].float()
        num_experts = probs.shape[-1]
        assignments = route["indices"].reshape(-1).long()
        if assignments.numel() == 0:
            losses.append(probs.sum() * 0.0)
            continue
        fraction = torch.bincount(assignments, minlength=num_experts).to(probs.dtype)
        fraction = fraction / assignments.numel()
        mean_probability = probs.reshape(-1, num_experts).mean(0)
        losses.append(num_experts * (fraction * mean_probability).sum())
    return torch.stack(losses).mean()


def _masked_bce(probability: torch.Tensor, target: torch.Tensor, valid: torch.Tensor):
    losses = F.binary_cross_entropy(probability.float().clamp(1e-6, 1 - 1e-6),
                                   target.detach().float(), reduction="none")
    return _masked_mean(losses, valid)


def compute_losses(
    output: Dict,
    labels: torch.Tensor,
    target_clean: torch.Tensor,
    valid_low: torch.Tensor,
    alpha_bar: torch.Tensor,
    utility: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
    enable_state: bool = True,
    enable_weather: bool = True,
) -> Dict[str, torch.Tensor]:
    """Combine the seven paper objectives with their reference coefficients."""
    zero = output["logits"].sum() * 0.0
    result = {"seg": masked_cross_entropy(output["logits"], labels)}
    reconstruction = (output["clean"].float() - target_clean.float()).square().mean(1, keepdim=True)
    result["rec"] = _masked_mean(reconstruction, valid_low)
    result["pre"] = masked_cross_entropy(output["pre_logits"], labels)
    target_risk, valid_tokens = risk_target(output["pre_logits"], labels, output["grid_size"])
    result["err"] = _masked_bce(output["risk"], target_risk, valid_tokens)
    result["str"] = zero
    if enable_state:
        result["str"] = structure_loss(output["routing"], labels, output["risk"],
                                       output["grid_size"], alpha_bar)
    result["util"] = zero
    if enable_weather and utility is not None:
        result["util"] = _masked_bce(output["gate"], utility[0], utility[1])
    result["bal"] = load_balance_loss(output["routing"]) if output["routing"] else zero
    result["total"] = (
        result["seg"] + result["rec"] + 0.4 * result["pre"] + 0.1 * result["err"]
        + 0.1 * result["util"] + 0.01 * result["str"] + 0.01 * result["bal"]
    )
    return result
