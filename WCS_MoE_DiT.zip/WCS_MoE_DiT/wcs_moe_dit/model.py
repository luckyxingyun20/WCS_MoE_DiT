"""A small, self-contained WCS-MoE-DiT mechanism demo.

This implementation preserves the dense-prefix/sparse-suffix, diagnostic,
weather-utility and diffusion interfaces described in the supplied manuscript.
The image encoder is a tiny CNN instead of pretrained MiT-B1. By default the
four weather text vectors are orthogonal category surrogates, NOT CLIP features;
the ``weather_text_embeddings_is_pretrained_clip`` buffer records this choice.
There are no dropout layers, including in attention and expert routing.
"""

import math
from typing import Dict, Optional, Tuple, Union

import torch
from torch import Tensor, nn
import torch.nn.functional as F
from torchvision.models import resnet18


WEATHER_CLASSES = ("fog", "night", "rain", "snow")


def _groups(width: int) -> int:
    for groups in (8, 4, 2, 1):
        if width % groups == 0:
            return groups
    return 1


class ConvStage(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, stride=2, padding=1),
            nn.GroupNorm(_groups(out_channels), out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.GroupNorm(_groups(out_channels), out_channels),
            nn.GELU(),
        )


class TinyHierarchicalEncoder(nn.Module):
    """Learned features at /4, /8, /16 and /32; no pretrained weights."""

    def __init__(self, width: int) -> None:
        super().__init__()
        self.stem = ConvStage(3, width // 2)
        self.stage4 = ConvStage(width // 2, width)
        self.stage8 = ConvStage(width, width)
        self.stage16 = ConvStage(width, width)
        self.stage32 = ConvStage(width, width)
        self.fuse16 = nn.Conv2d(width * 3, width, 1)

    def forward(self, image: Tensor) -> Tuple[Tensor, Tensor]:
        f4 = self.stage4(self.stem(image))
        f8 = self.stage8(f4)
        f16 = self.stage16(f8)
        f32 = self.stage32(f16)
        aligned = (
            F.interpolate(f8, size=f16.shape[-2:], mode="bilinear", align_corners=False),
            f16,
            F.interpolate(f32, size=f16.shape[-2:], mode="bilinear", align_corners=False),
        )
        return f4, self.fuse16(torch.cat(aligned, dim=1))


def timestep_embedding(timestep: Tensor, width: int) -> Tensor:
    """Standard sinusoidal diffusion embedding for raw integer timesteps."""
    half = width // 2
    frequencies = torch.exp(
        -math.log(10000.0)
        * torch.arange(half, device=timestep.device, dtype=torch.float32)
        / max(half, 1)
    )
    phases = timestep.float().reshape(-1, 1) * frequencies.reshape(1, -1)
    embedding = torch.cat((phases.cos(), phases.sin()), dim=-1)
    return F.pad(embedding, (0, width - embedding.shape[-1]))


def position_embedding(
    grid_size: Tuple[int, int], width: int, device: torch.device, dtype: torch.dtype
) -> Tensor:
    """Fixed 2D sine/cosine positions, generated for each input grid."""
    height, image_width = grid_size
    quarter = width // 4
    frequencies = torch.exp(
        -math.log(10000.0)
        * torch.arange(quarter, device=device, dtype=torch.float32)
        / max(quarter, 1)
    )
    yy, xx = torch.meshgrid(
        torch.arange(height, device=device, dtype=torch.float32),
        torch.arange(image_width, device=device, dtype=torch.float32),
        indexing="ij",
    )
    y = yy.reshape(-1, 1) * frequencies.reshape(1, -1)
    x = xx.reshape(-1, 1) * frequencies.reshape(1, -1)
    return torch.cat((x.sin(), x.cos(), y.sin(), y.cos()), dim=-1).to(dtype).unsqueeze(0)


class FFN(nn.Sequential):
    def __init__(self, width: int, hidden_width: int) -> None:
        super().__init__(nn.Linear(width, hidden_width), nn.GELU(), nn.Linear(hidden_width, width))


class RouterProjection(nn.Sequential):
    def __init__(self, input_width: int, output_width: int) -> None:
        super().__init__(nn.Linear(input_width, output_width), nn.LayerNorm(output_width), nn.GELU())


class AdaptiveAttention(nn.Module):
    """DiT-style timestep modulation of self/cross attention and the FFN input."""

    def __init__(self, width: int, num_heads: int) -> None:
        super().__init__()
        self.self_norm = nn.LayerNorm(width, elementwise_affine=False)
        self.cross_norm = nn.LayerNorm(width, elementwise_affine=False)
        self.image_norm = nn.LayerNorm(width)
        self.ffn_norm = nn.LayerNorm(width, elementwise_affine=False)
        self.self_attention = nn.MultiheadAttention(width, num_heads, dropout=0.0, batch_first=True)
        self.cross_attention = nn.MultiheadAttention(width, num_heads, dropout=0.0, batch_first=True)
        self.modulation = nn.Sequential(nn.SiLU(), nn.Linear(width, width * 9))

    @staticmethod
    def modulate(value: Tensor, shift: Tensor, scale: Tensor) -> Tensor:
        return value * (1.0 + scale.unsqueeze(1)) + shift.unsqueeze(1)

    def forward(self, tokens: Tensor, image_tokens: Tensor, time: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        shift_s, scale_s, gate_s, shift_c, scale_c, gate_c, shift_f, scale_f, gate_f = (
            self.modulation(time).chunk(9, dim=-1)
        )
        h = self.modulate(self.self_norm(tokens), shift_s, scale_s)
        tokens = tokens + gate_s.sigmoid().unsqueeze(1) * self.self_attention(h, h, h, need_weights=False)[0]
        h = self.modulate(self.cross_norm(tokens), shift_c, scale_c)
        context = self.image_norm(image_tokens)
        tokens = tokens + gate_c.sigmoid().unsqueeze(1) * self.cross_attention(
            h, context, context, need_weights=False
        )[0]
        h = self.modulate(self.ffn_norm(tokens), shift_f, scale_f)
        return tokens, h, gate_f.sigmoid().unsqueeze(1)


class DenseBlock(nn.Module):
    def __init__(self, width: int, num_heads: int) -> None:
        super().__init__()
        self.attention = AdaptiveAttention(width, num_heads)
        self.ffn = FFN(width, width * 4)

    def forward(self, tokens: Tensor, image_tokens: Tensor, time: Tensor) -> Tensor:
        tokens, h, gate = self.attention(tokens, image_tokens, time)
        return tokens + gate * self.ffn(h)


class SparseExperts(nn.Module):
    """Top-K dispatch evaluates routed FFNs only for their selected tokens."""

    def __init__(
        self,
        width: int,
        weather_width: int,
        num_experts: int,
        top_k: int,
        weather_delta: float,
        enable_weather: bool,
        enable_state: bool,
    ) -> None:
        super().__init__()
        self.num_experts = num_experts
        self.top_k = top_k
        self.weather_delta = weather_delta
        self.enable_weather = enable_weather
        self.enable_state = enable_state
        router_width = max(16, width // 2)
        self.visual_token = RouterProjection(width, router_width)
        self.visual_image = RouterProjection(width, router_width)
        self.visual_time = RouterProjection(width, router_width)
        self.visual_router = nn.Linear(router_width * 3, num_experts)
        self.weather_token = RouterProjection(width, router_width)
        self.weather_image = RouterProjection(width, router_width)
        self.weather_time = RouterProjection(width, router_width)
        self.weather_condition = RouterProjection(weather_width, router_width)
        self.weather_router = nn.Linear(router_width * 4, num_experts)
        self.state_condition = RouterProjection(3, router_width)
        self.state_time = RouterProjection(width, router_width)
        self.state_router = nn.Linear(router_width * 2, num_experts)
        self.experts = nn.ModuleList([FFN(width, width * 4) for _ in range(num_experts)])
        self.shared_expert = FFN(width, width * 2)

    def forward(
        self, tokens: Tensor, image_tokens: Tensor, time: Tensor,
        weather: Tensor, gate: Tensor, state: Tensor,
    ) -> Tuple[Tensor, Dict[str, Tensor]]:
        batch, count, width = tokens.shape
        visual_time = self.visual_time(time).unsqueeze(1).expand(-1, count, -1)
        scores = self.visual_router(torch.cat((
            self.visual_token(tokens), self.visual_image(image_tokens), visual_time,
        ), dim=-1))
        if self.enable_weather:
            weather_time = self.weather_time(time).unsqueeze(1).expand(-1, count, -1)
            weather_vector = self.weather_condition(weather).unsqueeze(1).expand(-1, count, -1)
            weather_scores = self.weather_router(torch.cat((
                self.weather_token(tokens), self.weather_image(image_tokens),
                weather_time, weather_vector,
            ), dim=-1)).tanh() * self.weather_delta
            scores = scores + gate.unsqueeze(-1) * weather_scores
        if self.enable_state:
            state_time = self.state_time(time).unsqueeze(1).expand(-1, count, -1)
            scores = scores + self.state_router(torch.cat((
                self.state_condition(state.detach()), state_time,
            ), dim=-1))
        probabilities = scores.softmax(dim=-1)
        weights, indices = probabilities.topk(self.top_k, dim=-1)
        weights = weights / weights.sum(dim=-1, keepdim=True).clamp_min(1e-8)
        flat_tokens = tokens.reshape(-1, width)
        flat_indices = indices.reshape(-1, self.top_k)
        flat_weights = weights.reshape(-1, self.top_k)
        routed_output = torch.zeros_like(flat_tokens)
        for expert_index, expert in enumerate(self.experts):
            token_index, selection_slot = torch.where(flat_indices == expert_index)
            if token_index.numel() == 0:
                continue
            selected_tokens = flat_tokens.index_select(0, token_index)
            expert_output = expert(selected_tokens)
            weighted_output = expert_output * flat_weights[token_index, selection_slot].unsqueeze(-1)
            routed_output.index_add_(0, token_index, weighted_output)
        result = routed_output.reshape(batch, count, width) + self.shared_expert(tokens)
        return result, {"probs": probabilities, "indices": indices, "weights": weights}


class ExpertBlock(nn.Module):
    def __init__(self, width: int, num_heads: int, **expert_kwargs) -> None:
        super().__init__()
        self.attention = AdaptiveAttention(width, num_heads)
        self.moe = SparseExperts(width=width, **expert_kwargs)

    def forward(
        self, tokens: Tensor, image_tokens: Tensor, time: Tensor,
        weather: Tensor, gate: Tensor, state: Tensor,
    ) -> Tuple[Tensor, Dict[str, Tensor]]:
        tokens, h, residual_gate = self.attention(tokens, image_tokens, time)
        expert_output, routing = self.moe(h, image_tokens, time, weather, gate, state)
        return tokens + residual_gate * expert_output, routing


class WCSMoEDiT(nn.Module):
    """Tiny RGB-conditioned semantic mask denoiser with a reusable prefix.

    The default classifier is an untrained four-class ResNet-18 and is frozen.
    The runner can initialize its backbone from local ImageNet weights and train
    its weather head before segmentation. No weight downloads occur here.
    """

    def __init__(
        self, width: int = 64, prefix_depth: int = 1, suffix_depth: int = 1,
        num_classes: int = 19, num_experts: int = 4, top_k: int = 2,
        num_heads: int = 4, weather_embedding_dim: int = 32,
        weather_delta: float = 1.0, enable_weather: bool = True, enable_state: bool = True,
    ) -> None:
        super().__init__()
        if width < 16 or width % 4 or width % num_heads:
            raise ValueError("width must be at least 16 and divisible by 4 and num_heads")
        if not 1 <= top_k <= num_experts:
            raise ValueError("top_k must be between 1 and num_experts")
        if min(prefix_depth, suffix_depth) < 1:
            raise ValueError("prefix_depth and suffix_depth must be positive")
        if weather_embedding_dim < 4 or weather_delta <= 0:
            raise ValueError("weather_embedding_dim must be >=4 and weather_delta must be positive")
        self.width = width
        self.num_classes = num_classes
        self.enable_weather = enable_weather
        self.enable_state = enable_state
        self.weather_classes = WEATHER_CLASSES
        self.image_encoder = TinyHierarchicalEncoder(width)
        self.mask_embedding = nn.Conv2d(num_classes, width, kernel_size=4, stride=4)
        self.time_embedding = nn.Sequential(nn.Linear(width, width * 4), nn.SiLU(), nn.Linear(width * 4, width))
        self.prefix_blocks = nn.ModuleList([DenseBlock(width, num_heads) for _ in range(prefix_depth)])
        self.suffix_blocks = nn.ModuleList([
            ExpertBlock(
                width, num_heads, weather_width=width,
                num_experts=num_experts, top_k=top_k, weather_delta=weather_delta,
                enable_weather=enable_weather, enable_state=enable_state,
            )
            for _ in range(suffix_depth)
        ])
        self.weather_classifier = resnet18(weights=None)
        self.weather_classifier.fc = nn.Linear(self.weather_classifier.fc.in_features, 4)
        self.weather_classifier.requires_grad_(False)
        self.weather_classifier.eval()
        surrogate = torch.zeros(4, weather_embedding_dim)
        surrogate[:, :4] = torch.eye(4)
        self.register_buffer("weather_embeddings", surrogate)
        self.register_buffer("weather_text_embeddings_is_pretrained_clip", torch.tensor(False))
        self.weather_projection = nn.Sequential(
            nn.Linear(weather_embedding_dim, width),
            nn.LayerNorm(width), nn.GELU(),
        )
        router_width = max(16, width // 2)
        self.risk_token = RouterProjection(width, router_width)
        self.risk_image = RouterProjection(width, router_width)
        self.risk_time = RouterProjection(width, router_width)
        self.risk_head = nn.Sequential(nn.Linear(router_width * 3, router_width), nn.GELU(), nn.Linear(router_width, 1))
        self.gate_token = RouterProjection(width, router_width)
        self.gate_image = RouterProjection(width, router_width)
        self.gate_time = RouterProjection(width, router_width)
        self.gate_weather = RouterProjection(width, router_width)
        self.gate_head = nn.Sequential(nn.Linear(router_width * 4 + 1, router_width), nn.GELU(), nn.Linear(router_width, 1))
        self.prefix_decode = nn.Sequential(
            nn.ConvTranspose2d(width, width, 4, stride=4), nn.GELU(), nn.Conv2d(width, num_classes, 1),
        )
        self.suffix_decode = nn.Sequential(nn.ConvTranspose2d(width, width, 4, stride=4), nn.GELU())
        self.low_head = nn.Conv2d(width, num_classes, 1)
        self.output_head = nn.Sequential(
            nn.Conv2d(width * 2, width, 3, padding=1),
            nn.GroupNorm(_groups(width), width), nn.GELU(), nn.Conv2d(width, num_classes, 1),
        )

    def train(self, mode: bool = True):
        super().train(mode)
        if not any(parameter.requires_grad for parameter in self.weather_classifier.parameters()):
            self.weather_classifier.eval()
        return self

    @property
    def weather_text_embeddings(self) -> Tensor:
        """Descriptive alias for the public ``weather_embeddings`` buffer."""
        return self.weather_embeddings

    @torch.no_grad()
    def set_weather_text_embeddings(self, embeddings: Tensor, is_pretrained_clip: bool = True) -> None:
        """Replace the surrogate with supplied normalized [4,D] text features."""
        if embeddings.shape != self.weather_text_embeddings.shape:
            raise ValueError("weather text embeddings must have shape %s" % (tuple(self.weather_text_embeddings.shape),))
        if not torch.isfinite(embeddings).all() or (embeddings.norm(dim=-1) <= 0).any():
            raise ValueError("weather text embeddings must be finite and nonzero")
        self.weather_text_embeddings.copy_(F.normalize(embeddings.to(self.weather_text_embeddings), dim=-1))
        self.weather_text_embeddings_is_pretrained_clip.fill_(bool(is_pretrained_clip))

    def encode_condition(self, image: Tensor, weather_probs: Optional[Tensor] = None) -> Dict:
        """Cache image and weather features once, before all denoising steps."""
        if image.ndim != 4 or image.shape[1] != 3:
            raise ValueError("image must have shape [B,3,H,W]")
        height, image_width = image.shape[-2:]
        padded_height = max(32, math.ceil(height / 32) * 32)
        padded_width = max(32, math.ceil(image_width / 32) * 32)
        padded_image = F.pad(image, (0, padded_width - image_width, 0, padded_height - height))
        f4, f16 = self.image_encoder(padded_image)
        grid_size = tuple(f16.shape[-2:])
        image_tokens = f16.flatten(2).transpose(1, 2)
        image_tokens = image_tokens + position_embedding(grid_size, self.width, image.device, image_tokens.dtype)
        if weather_probs is None:
            with torch.no_grad():
                mean = image.new_tensor((0.485, 0.456, 0.406)).reshape(1, 3, 1, 1)
                std = image.new_tensor((0.229, 0.224, 0.225)).reshape(1, 3, 1, 1)
                weather_probs = self.weather_classifier((image - mean) / std).softmax(dim=-1)
        else:
            if weather_probs.shape != (image.shape[0], 4):
                raise ValueError("weather_probs must have shape [B,4]")
            weather_probs = weather_probs.to(device=image.device, dtype=image.dtype).detach()
            if not torch.isfinite(weather_probs).all() or (weather_probs < 0).any():
                raise ValueError("weather_probs must be finite and nonnegative")
            sums = weather_probs.sum(dim=-1, keepdim=True)
            if (sums <= 0).any():
                raise ValueError("weather_probs must have positive sums")
            weather_probs = weather_probs / sums
        weather_probs = weather_probs.detach()
        weighted_text = weather_probs @ self.weather_text_embeddings.to(weather_probs)
        weather_vector = self.weather_projection(weighted_text)
        return {
            "f4": f4, "img_tokens": image_tokens, "weather_probs": weather_probs,
            "weather_vector": weather_vector, "image_size": (height, image_width),
            "padded_size": (padded_height, padded_width), "grid_size": grid_size,
            "low_size": (math.ceil(height / 4), math.ceil(image_width / 4)),
        }

    @staticmethod
    @torch.no_grad()
    def _diagnostics(pre_logits: Tensor, padded_size: Tuple[int, int]) -> Tuple[Tensor, Tensor]:
        """Entropy mean and maximum four-neighbor half-L1 per 16px footprint."""
        probabilities = pre_logits.detach().softmax(dim=1)
        entropy = -(probabilities * probabilities.clamp_min(1e-8).log()).sum(dim=1, keepdim=True)
        entropy = entropy / math.log(probabilities.shape[1])
        boundary = torch.zeros_like(entropy)
        horizontal = (probabilities[:, :, :, 1:] - probabilities[:, :, :, :-1]).abs().sum(dim=1, keepdim=True) * 0.5
        vertical = (probabilities[:, :, 1:, :] - probabilities[:, :, :-1, :]).abs().sum(dim=1, keepdim=True) * 0.5
        boundary[:, :, :, :-1] = torch.maximum(boundary[:, :, :, :-1], horizontal)
        boundary[:, :, :, 1:] = torch.maximum(boundary[:, :, :, 1:], horizontal)
        boundary[:, :, :-1, :] = torch.maximum(boundary[:, :, :-1, :], vertical)
        boundary[:, :, 1:, :] = torch.maximum(boundary[:, :, 1:, :], vertical)
        padding = (0, padded_size[1] - pre_logits.shape[-1], 0, padded_size[0] - pre_logits.shape[-2])
        valid = F.pad(torch.ones_like(entropy), padding)
        entropy = F.avg_pool2d(F.pad(entropy, padding), 16, 16) / F.avg_pool2d(valid, 16, 16).clamp_min(1e-8)
        boundary = F.max_pool2d(F.pad(boundary, padding), 16, 16)
        return entropy.flatten(1), boundary.flatten(1)

    def prepare_prefix(self, x_t: Tensor, t: Tensor, condition: Dict) -> Dict:
        """Compute the prefix and detached routing diagnostics once per call."""
        if x_t.ndim != 4 or x_t.shape[1] != self.num_classes:
            raise ValueError("x_t must have shape [B,num_classes,ceil(H/4),ceil(W/4)]")
        if tuple(x_t.shape[-2:]) != condition["low_size"]:
            raise ValueError("x_t spatial dimensions must match the quarter-resolution image")
        batch = x_t.shape[0]
        if t.ndim == 0:
            t = t.expand(batch)
        if t.numel() != batch:
            raise ValueError("t must contain one timestep per batch element")
        image_tokens = condition["img_tokens"]
        time = self.time_embedding(timestep_embedding(t, self.width).to(image_tokens.dtype))
        padded_height, padded_width = condition["padded_size"]
        padded_mask = F.pad(x_t, (0, padded_width // 4 - x_t.shape[-1], 0, padded_height // 4 - x_t.shape[-2]))
        tokens = self.mask_embedding(padded_mask).flatten(2).transpose(1, 2)
        tokens = tokens + position_embedding(condition["grid_size"], self.width, x_t.device, tokens.dtype)
        for block in self.prefix_blocks:
            tokens = block(tokens, image_tokens, time)
        grid_height, grid_width = condition["grid_size"]
        token_map = tokens.transpose(1, 2).reshape(batch, self.width, grid_height, grid_width)
        pre_logits = self.prefix_decode(token_map)
        pre_logits = F.interpolate(pre_logits, size=condition["padded_size"], mode="bilinear", align_corners=False)
        height, image_width = condition["image_size"]
        pre_logits = pre_logits[:, :, :height, :image_width]
        count = tokens.shape[1]
        risk_time = self.risk_time(time).unsqueeze(1).expand(-1, count, -1)
        risk = self.risk_head(torch.cat((
            self.risk_token(tokens), self.risk_image(image_tokens), risk_time,
        ), dim=-1)).squeeze(-1).sigmoid()
        weather = condition["weather_vector"]
        gate_time = self.gate_time(time).unsqueeze(1).expand(-1, count, -1)
        gate_weather = self.gate_weather(weather).unsqueeze(1).expand(-1, count, -1)
        weather_probs = condition["weather_probs"]
        weather_entropy = -(weather_probs * weather_probs.clamp_min(1e-8).log()).sum(dim=-1, keepdim=True) / math.log(4)
        gate_entropy = weather_entropy.unsqueeze(1).expand(-1, count, -1)
        gate = self.gate_head(torch.cat((
            self.gate_token(tokens), self.gate_image(image_tokens), gate_time, gate_weather, gate_entropy,
        ), dim=-1)).squeeze(-1).sigmoid()
        entropy, boundary = self._diagnostics(pre_logits, condition["padded_size"])
        state = torch.stack((entropy, boundary, risk.detach()), dim=-1).detach()
        return {
            "tokens": tokens, "image_tokens": image_tokens, "time": time,
            "pre_logits": pre_logits, "risk": risk, "gate": gate, "state": state,
            "grid_size": condition["grid_size"], "condition": condition,
        }

    def decode_suffix(
        self, prefix: Dict, weather_gate_override: Optional[Union[float, Tensor]] = None,
    ) -> Dict:
        """Reuse one prefix for learned-gate, ON and OFF suffix evaluations."""
        condition = prefix["condition"]
        tokens = prefix["tokens"]
        gate = prefix["gate"]
        if weather_gate_override is not None:
            if isinstance(weather_gate_override, Tensor):
                gate = torch.broadcast_to(weather_gate_override.to(gate), gate.shape)
            else:
                gate = torch.full_like(gate, float(weather_gate_override))
        routing = []
        for block in self.suffix_blocks:
            tokens, layer_routing = block(
                tokens, prefix["image_tokens"], prefix["time"],
                condition["weather_vector"], gate, prefix["state"],
            )
            routing.append(layer_routing)
        grid_height, grid_width = prefix["grid_size"]
        token_map = tokens.transpose(1, 2).reshape(tokens.shape[0], self.width, grid_height, grid_width)
        decoded = self.suffix_decode(token_map)
        low_logits = self.low_head(decoded)
        low_height, low_width = condition["low_size"]
        low_logits = low_logits[:, :, :low_height, :low_width]
        output_logits = self.output_head(torch.cat((decoded, condition["f4"]), dim=1))
        output_logits = F.interpolate(output_logits, size=condition["padded_size"], mode="bilinear", align_corners=False)
        height, image_width = condition["image_size"]
        output_logits = output_logits[:, :, :height, :image_width]
        result = {key: value for key, value in prefix.items() if key not in ("tokens", "image_tokens", "time", "condition")}
        result.update({
            "logits": output_logits, "low_logits": low_logits,
            "clean": 2.0 * low_logits.softmax(dim=1) - 1.0, "routing": routing,
        })
        return result

    def forward(
        self, image: Tensor, x_t: Tensor, t: Tensor,
        weather_probs: Optional[Tensor] = None, weather_gate_override: Optional[Union[float, Tensor]] = None,
    ) -> Dict:
        condition = self.encode_condition(image, weather_probs=weather_probs)
        prefix = self.prepare_prefix(x_t, t, condition)
        return self.decode_suffix(prefix, weather_gate_override=weather_gate_override)
