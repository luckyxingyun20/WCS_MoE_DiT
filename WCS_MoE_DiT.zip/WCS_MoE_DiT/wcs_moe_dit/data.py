"""Small, supervised ACDC loader with Cityscapes-compatible labels."""

from pathlib import Path
from typing import Optional, Sequence, Union

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset


WEATHER_NAMES = ["fog", "night", "rain", "snow"]
CLASS_NAMES = [
    "road", "sidewalk", "building", "wall", "fence", "pole",
    "traffic light", "traffic sign", "vegetation", "terrain", "sky",
    "person", "rider", "car", "truck", "bus", "train", "motorcycle",
    "bicycle",
]
PALETTE = np.asarray([
    [128, 64, 128], [244, 35, 232], [70, 70, 70], [102, 102, 156],
    [190, 153, 153], [153, 153, 153], [250, 170, 30], [220, 220, 0],
    [107, 142, 35], [152, 251, 152], [70, 130, 180], [220, 20, 60],
    [255, 0, 0], [0, 0, 142], [0, 0, 70], [0, 60, 100],
    [0, 80, 100], [0, 0, 230], [119, 11, 32],
], dtype=np.uint8)
IGNORE_INDEX = 255
_LABEL_IDS = [7, 8, 11, 12, 13, 17, 19, 20, 21, 22, 23, 24, 25,
              26, 27, 28, 31, 32, 33]
_LABEL_LOOKUP = np.full(256, IGNORE_INDEX, dtype=np.uint8)
for _train_id, _label_id in enumerate(_LABEL_IDS):
    _LABEL_LOOKUP[_label_id] = _train_id


def colorize_mask(mask: np.ndarray) -> np.ndarray:
    """Return a Cityscapes RGB visualization; ignored pixels are black."""
    mask = np.asarray(mask)
    if mask.ndim != 2:
        raise ValueError("colorize_mask expects a two-dimensional class mask")
    colored = np.zeros((*mask.shape, 3), dtype=np.uint8)
    valid = (mask >= 0) & (mask < len(CLASS_NAMES))
    colored[valid] = PALETTE[mask[valid].astype(np.int64)]
    return colored


def _find_root(root: Path, kind: str) -> Path:
    candidates = {
        "rgb": [root / "rgb_anon_trainvaltest" / "rgb_anon", root / "rgb_anon"],
        "gt": [root / "gt_trainval" / "gt", root / "gt"],
    }[kind]
    for candidate in candidates:
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError(
        "Cannot find ACDC {} directory; tried {}".format(
            kind, ", ".join(str(candidate) for candidate in candidates)
        )
    )


class ACDCDataset(Dataset):
    """Load actual adverse-weather RGB images and their semantic annotations.

    The demo limit selects the first sorted images separately for every
    requested condition. Set ``limit_per_weather=None`` to load the full split.
    Normal-weather reference images and uncertainty masks are not targets.
    """

    def __init__(
        self,
        root: Union[str, Path] = "/home/neu/dataset/ACDC",
        split: str = "train",
        image_size: Union[int, Sequence[int]] = 128,
        limit_per_weather: Optional[int] = 2,
        weather: Optional[Union[str, Sequence[str]]] = None,
        augment: bool = False,
    ):
        if split not in ("train", "val"):
            raise ValueError("Supervised ACDC demo supports only train and val splits")
        if isinstance(image_size, (int, np.integer)):
            size = (int(image_size), int(image_size))
        else:
            size = tuple(image_size)
        if (len(size) != 2 or any(not isinstance(x, (int, np.integer)) for x in size)
                or any(x <= 0 or x % 16 != 0 for x in size)):
            raise ValueError("image_size must contain positive multiples of 16")
        if limit_per_weather is not None and (
            not isinstance(limit_per_weather, int) or limit_per_weather <= 0
        ):
            raise ValueError("limit_per_weather must be positive or None")
        selected = WEATHER_NAMES if weather is None else (
            [weather] if isinstance(weather, str) else list(weather)
        )
        if not selected or any(name not in WEATHER_NAMES for name in selected):
            raise ValueError("weather must select from {}".format(WEATHER_NAMES))
        # Canonical ordering avoids duplicates and preserves global weather IDs.
        selected = [name for name in WEATHER_NAMES if name in selected]
        self.root = Path(root).expanduser().resolve()
        self.split = split
        self.image_size = (int(size[0]), int(size[1]))
        self.augment = bool(augment)
        self.rgb_root = _find_root(self.root, "rgb")
        self.gt_root = _find_root(self.root, "gt")
        self.samples = []
        for weather_name in selected:
            rgb_split = self.rgb_root / weather_name / split
            images = sorted(rgb_split.rglob("*_rgb_anon.png"))
            if not images:
                raise FileNotFoundError("No RGB images found in {}".format(rgb_split))
            if limit_per_weather is not None:
                images = images[:limit_per_weather]
            for image_path in images:
                relative = image_path.relative_to(rgb_split)
                stem = image_path.name[:-len("_rgb_anon.png")]
                label_dir = self.gt_root / weather_name / split / relative.parent
                label_path = label_dir / (stem + "_gt_labelTrainIds.png")
                if not label_path.is_file():
                    label_path = label_dir / (stem + "_gt_labelIds.png")
                if not label_path.is_file():
                    raise FileNotFoundError(
                        "Missing semantic ground truth for {}".format(image_path)
                    )
                self.samples.append({
                    "image_path": str(image_path),
                    "label_path": str(label_path),
                    "weather_name": weather_name,
                    "weather_id": WEATHER_NAMES.index(weather_name),
                })

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        record = self.samples[index]
        height, width = self.image_size
        with Image.open(record["image_path"]) as source:
            image = np.asarray(
                source.convert("RGB").resize((width, height), Image.Resampling.BILINEAR),
                dtype=np.float32,
            ).copy() / 255.0
        with Image.open(record["label_path"]) as source:
            label = np.asarray(
                source.resize((width, height), Image.Resampling.NEAREST),
                dtype=np.int64,
            ).copy()
        if label.ndim != 2:
            raise ValueError("Semantic ground truth must be a single-channel mask")
        if record["label_path"].endswith("_gt_labelIds.png"):
            mapped = np.full(label.shape, IGNORE_INDEX, dtype=np.int64)
            valid = (label >= 0) & (label < len(_LABEL_LOOKUP))
            mapped[valid] = _LABEL_LOOKUP[label[valid]]
            label = mapped
        else:
            label[(label < 0) | (label >= len(CLASS_NAMES))] = IGNORE_INDEX
        image = torch.from_numpy(image).permute(2, 0, 1).contiguous()
        label = torch.from_numpy(label).long()
        if self.augment and torch.rand(()).item() < 0.5:
            image = image.flip(-1)
            label = label.flip(-1)
        return {
            "image": image,
            "label": label,
            "weather": torch.tensor(record["weather_id"], dtype=torch.long),
            "image_path": record["image_path"],
            "label_path": record["label_path"],
            "weather_name": record["weather_name"],
        }
