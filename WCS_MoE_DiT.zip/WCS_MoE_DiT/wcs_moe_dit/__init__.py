"""Runnable lightweight WCS-MoE-DiT demo package."""

from .model import WCSMoEDiT

__all__ = ["WCSMoEDiT"]
